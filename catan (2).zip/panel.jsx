// Side panel: brand, turn, phase, players, hand, log, dice, actions, trade
const { useState: useStateP } = React;

// Shared resource-icon SVG. Used in hand cards, player rows, action costs, dev cards.
function ResIcon({ kind, size = 16 }) {
  const common = { strokeWidth: 1.2, strokeLinejoin: 'round', strokeLinecap: 'round' };
  const s = size;
  if (kind === 'wood')  return (<svg viewBox="0 0 40 40" width={s} height={s}><path d="M20 4 L8 22 L14 22 L6 34 L34 34 L26 22 L32 22 Z" fill="#1c3d1c" stroke="#0e2210" {...common}/><path d="M20 8 L12 22 M20 8 L28 22" stroke="#2d5a2d" strokeWidth="1.5" fill="none"/></svg>);
  if (kind === 'brick') return (<svg viewBox="0 0 40 40" width={s} height={s}>{[0,1,2].map(r=>(<g key={r} transform={`translate(${(r%2)*4 - 2} ${r*9+4})`}><rect width="18" height="7" fill="#7a2c16" stroke="#4a1a0a" {...common}/><rect x="20" width="18" height="7" fill="#7a2c16" stroke="#4a1a0a" {...common}/></g>))}</svg>);
  if (kind === 'wheat') return (<svg viewBox="0 0 40 40" width={s} height={s}><path d="M20 4 Q14 18 20 34 Q26 18 20 4 Z" fill="#b88a1d" stroke="#5a4208" {...common}/><path d="M14 12 Q18 16 20 18 M26 12 Q22 16 20 18 M13 20 Q18 24 20 25 M27 20 Q22 24 20 25" stroke="#5a4208" strokeWidth="1.4" fill="none"/></svg>);
  if (kind === 'sheep') return (<svg viewBox="0 0 40 40" width={s} height={s}><ellipse cx="18" cy="24" rx="14" ry="10" fill="#f1ead4" stroke="#6a9130" {...common}/><circle cx="30" cy="18" r="5" fill="#2a2a2a"/><circle cx="32" cy="16.5" r=".9" fill="#fff"/></svg>);
  if (kind === 'ore')   return (<svg viewBox="0 0 40 40" width={s} height={s}><path d="M4 32 L12 14 L22 10 L30 18 L36 32 Z" fill="#474e58" stroke="#1f242c" {...common}/><path d="M12 14 L18 24 L22 10 M22 10 L26 22 L30 18" stroke="#8a95a2" strokeWidth="1.3" fill="none"/></svg>);
  if (kind === 'hand')  return (<svg viewBox="0 0 40 40" width={s} height={s} aria-hidden="true"><path d="M14 28 L14 12 Q14 9 17 9 Q20 9 20 12 L20 22 M20 22 L20 8 Q20 5 23 5 Q26 5 26 8 L26 22 M26 22 L26 10 Q26 7 29 7 Q32 7 32 10 L32 26 Q32 34 24 34 Q18 34 14 30 Z" fill="none" stroke="#5b4a32" strokeWidth="1.6" {...common}/></svg>);
  if (kind === 'dev')   return (<svg viewBox="0 0 40 40" width={s} height={s} aria-hidden="true"><path d="M20 4 L34 20 L20 36 L6 20 Z" fill="#5b4a32" stroke="#2b1f12" strokeWidth="1.4"/><path d="M20 12 L28 20 L20 28 L12 20 Z" fill="#f6ecd4"/></svg>);
  if (kind === 'vp')    return (<svg viewBox="0 0 40 40" width={s} height={s} aria-hidden="true"><path d="M20 4 L24 15 L35 15 L26 22 L29 33 L20 26 L11 33 L14 22 L5 15 L16 15 Z" fill="#c8953a" stroke="#5b4a32" strokeWidth="1.2"/></svg>);
  return null;
}

function ResourceCard({ kind, n }) {
  const isSetup = window.__katanIsSetup;
  return (
    <div className={'rcard ' + kind + (isSetup ? ' slot' : (n === 0 ? ' zero' : ''))}>
      <div className="rn">{n}</div>
      <div className="ric"><ResIcon kind={kind} size={34}/></div>
      <div className="rl">{kind}</div>
    </div>
  );
}

function CostRow({ items }) {
  return (
    <span className="cost-row">
      {items.map((k, i) => <ResIcon key={i} kind={k} size={11}/>)}
    </span>
  );
}

function Die({ value, rolling, blank }) {
  const patterns = { 1:[4], 2:[0,8], 3:[0,4,8], 4:[0,2,6,8], 5:[0,2,4,6,8], 6:[0,2,3,5,6,8] };
  const active = new Set(blank ? [] : (patterns[value] || []));
  return (
    <div className={'die' + (rolling ? ' rolling' : '') + (blank ? ' blank' : '')}>
      {[...Array(9)].map((_, i) => (
        <span key={i} className={'pip' + (active.has(i) ? '' : ' hidden')} />
      ))}
    </div>
  );
}

const DEV_COLORS = {
  'Knight':         '#6a7480',
  'Road Building':  '#2d5a2d',
  'Year of Plenty': '#e5b547',
  'Monopoly':       '#b34a2a',
  'Victory Point':  '#c8953a',
};

function Panel(props) {
  const {
    players, currentPlayerIdx, phase, phaseMsg, log,
    dice, rolling, onRoll, onEndTurn, onBuild, onUndo,
    canRoll, canEnd, canBuild, turn,
    tradeSel, setTradeSel, onBankTrade, onPlayKnight,
  } = props;

  const p = players[currentPlayerIdx];
  const resNames = ['wood','brick','wheat','sheep','ore'];
  const isSetup = phase === 'placeSettlement1' || phase === 'placeSettlement2'
               || phase === 'placeRoad1'       || phase === 'placeRoad2';
  window.__katanIsSetup = isSetup;

  const phaseTitles = {
    idle: 'Roll to begin',
    rolled: 'Trade, build, or end turn',
    placeSettlement1: 'Place your first settlement',
    placeRoad1: 'Place a road from that settlement',
    placeSettlement2: 'Place your second settlement',
    placeRoad2: 'Place a road from that settlement',
    buildSettlement: 'Place a new settlement',
    buildCity: 'Upgrade a settlement to a city',
    buildRoad: 'Place a new road',
    moveRobber: 'A 7! Move the robber',
    gameOver: 'Game Over',
  };

  const leader = players.reduce((m, x) => x.vp > m.vp ? x : m, players[0]);

  return (
    <div className="panel">
      <div className="panel-inner">
        <h1 className="brand">KATAN</h1>
        <div className="brand-sub">Hex Isle · round {turn} · first to 10</div>
        <div className="rule"/>

        {/* Turn card */}
        <div className="turn-card">
          <div className="turn-chip" style={{background: p.rawColor}}/>
          <div>
            <div className="turn-label">Now playing</div>
            <div className="turn-name">{p.name}</div>
          </div>
          <div className="turn-meta">
            <div className="turn-vp"><span className="big">{p.vp}</span><span className="small">/ 10 VP</span></div>
            <div className="turn-hand">HAND {resNames.reduce((s,r)=>s+p.res[r],0)}</div>
          </div>
        </div>

        <h2 className="phase-title">{phaseTitles[phase] || phaseMsg}</h2>
        {phaseMsg && phase !== 'idle' && phase !== 'rolled' && <p className="phase-hint">{phaseMsg}</p>}

        {/* P2-4: Log under turn card — immediate context for what just happened. */}
        <div className="section-h">Game log</div>
        <div className="log">
          {log.slice().reverse().slice(0, isSetup ? 4 : 6).map((e,i)=>(
            <div key={i}><span className="t">T{e.turn}</span><span className="s">{e.text}</span></div>
          ))}
        </div>

        {/* Dice tray — gated/neutralized during setup */}
        <div className={'dice-tray' + (isSetup ? ' setup' : '')}>
          <Die value={dice[0]} rolling={rolling} blank={isSetup}/>
          <Die value={dice[1]} rolling={rolling} blank={isSetup}/>
          <div className="dice-result">
            {isSetup ? '—' : dice[0] + dice[1]}
            <small>{isSetup ? 'setup' : (rolling ? 'rolling' : 'sum')}</small>
          </div>
          <button className={'btn ' + (isSetup ? 'ghost' : 'primary')} style={{marginLeft:'auto'}}
            onClick={onRoll} disabled={!canRoll || rolling}>
            {rolling ? '…' : 'Roll'}
          </button>
        </div>

        {/* Players */}
        <div className="section-h">Players</div>
        {players.map((pl, i) => {
          const hand = Object.values(pl.res).reduce((a,b)=>a+b,0);
          return (
            <div key={pl.id} className={'player-row'+(i===currentPlayerIdx?' active':'')}>
              <span className="player-swatch" style={{background: pl.rawColor}}/>
              <span className="player-name">{pl.name}</span>
              <span className="stat-pill vp" title="Victory points">
                <span className="pill-n" style={{color: pl.rawColor}}>{pl.vp}</span><span className="pill-l">VP</span>
              </span>
              <span className="stat-pill" title="Cards in hand">
                <ResIcon kind="hand" size={11}/> {hand}
              </span>
              <span className="stat-pill" title="Development cards">
                <ResIcon kind="dev" size={11}/> {pl.dev || 0}
              </span>
            </div>
          );
        })}

        {/* Your hand */}
        <div className="section-h">Your hand</div>
        <div className="hand">
          {resNames.map(r => <ResourceCard key={r} kind={r} n={p.res[r]}/>)}
        </div>

        {/* Dev cards */}
        {(p.devList && p.devList.length > 0) && (
          <>
            <div className="section-h">Development</div>
            <div className="devcards">
              {p.devList.map((d,i)=>(
                <span key={i} className="devcard" style={{borderColor: DEV_COLORS[d] || 'var(--parch-rule)', color: DEV_COLORS[d] || 'var(--parch-ink)'}}>
                  {d==='Victory Point' ? <ResIcon kind="vp" size={10}/> : <ResIcon kind="dev" size={10}/>}
                  <span style={{marginLeft:5}}>{d}</span>
                </span>
              ))}
            </div>
            {/* Rule 22: Play-dev-card affordance, visible only when rolled and a playable card exists. */}
            {phase === 'rolled' && p.devList.includes('Knight') && (
              <button className="btn ghost play-dev" onClick={onPlayKnight}>
                <ResIcon kind="dev" size={12}/><span style={{marginLeft:6}}>Play Knight</span>
              </button>
            )}
          </>
        )}

        {/* Actions — hidden during setup to reduce clutter (P2-4) */}
        {!isSetup && <>
          <div className="section-h">Actions</div>
        <div className="action-row">
          <button className="btn ghost" onClick={()=>onBuild('road')} disabled={!canBuild || phase!=='rolled'}>
            Road <CostRow items={['wood','brick']}/>
          </button>
          <button className="btn ghost" onClick={()=>onBuild('settlement')} disabled={!canBuild || phase!=='rolled'}>
            Settlement <CostRow items={['wood','brick','wheat','sheep']}/>
          </button>
          <button className="btn ghost" onClick={()=>onBuild('city')} disabled={!canBuild || phase!=='rolled'}>
            City <CostRow items={['wheat','wheat','ore','ore','ore']}/>
          </button>
          <button className="btn ghost" onClick={()=>onBuild('dev')} disabled={!canBuild || phase!=='rolled'}>
            Dev Card <CostRow items={['wheat','sheep','ore']}/>
          </button>
        </div>

        {/* Bank trade */}
        <div className="section-h">Bank trade (4:1)</div>
        <div className="trade-bar">
          <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
            {resNames.map(r => (
              <span key={r} className={'trade-chip'+(tradeSel.give===r?' sel':'')}
                onClick={()=>setTradeSel({...tradeSel, give:r})}>
                <ResIcon kind={r} size={11}/> −
              </span>
            ))}
          </div>
          <span style={{fontFamily:'Cormorant Garamond', fontSize:20, color:'var(--parch-ink-soft)'}}>→</span>
          <div style={{display:'flex', gap:4, flexWrap:'wrap'}}>
            {resNames.map(r => (
              <span key={r} className={'trade-chip'+(tradeSel.get===r?' sel':'')}
                onClick={()=>setTradeSel({...tradeSel, get:r})}>
                <ResIcon kind={r} size={11}/> +
              </span>
            ))}
          </div>
        </div>
        <div style={{marginTop:8}}>
          <button className="btn ghost" style={{width:'100%'}}
            onClick={onBankTrade}
            disabled={!tradeSel.give || !tradeSel.get || tradeSel.give===tradeSel.get || phase!=='rolled' || p.res[tradeSel.give] < 4}>
            Trade 4 {tradeSel.give||'?'} for 1 {tradeSel.get||'?'}
          </button>
        </div>
        </>}

        {/* End turn */}
        <div className="action-row" style={{marginTop: 12}}>
          <button className="btn ghost" onClick={onUndo}>New game</button>
          <button className="btn primary" onClick={onEndTurn} disabled={!canEnd}>End turn ▸</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Panel, Die, ResIcon });
