// Board rendering: hex grid, number chits, harbors, settlements/roads, robber
const { useMemo } = React;

// Hex geometry (pointy-top)
const HEX_SIZE = 78;                 // radius (center to vertex)
const SQRT3 = Math.sqrt(3);
const BOARD_CX = 500;
const BOARD_CY = 510;

// Axial (q,r) -> pixel (pointy-top)
function axialToPx(q, r) {
  const x = HEX_SIZE * SQRT3 * (q + r / 2);
  const y = HEX_SIZE * 1.5 * r;
  return { x: BOARD_CX + x, y: BOARD_CY + y };
}

// Standard Catan layout: 19 hexes (3-4-5-4-3)
const HEX_COORDS = [
  // r = -2
  [0,-2], [1,-2], [2,-2],
  // r = -1
  [-1,-1],[0,-1],[1,-1],[2,-1],
  // r = 0
  [-2,0],[-1,0],[0,0],[1,0],[2,0],
  // r = 1
  [-2,1],[-1,1],[0,1],[1,1],
  // r = 2
  [-2,2],[-1,2],[0,2],
];

// Pointy-top hex corners relative to center
// Side i sits between corner i and corner i+1; edge-midpoint angle is 60*i (mod 360).
function hexCorners(cx, cy, size=HEX_SIZE) {
  const pts = [];
  for (let i=0;i<6;i++){
    const a = Math.PI / 180 * (60*i - 30);
    pts.push([cx + size*Math.cos(a), cy + size*Math.sin(a)]);
  }
  return pts;
}
function hexPath(cx, cy, size=HEX_SIZE) {
  return hexCorners(cx,cy,size).map(([x,y],i)=>(i?'L':'M')+x.toFixed(1)+' '+y.toFixed(1)).join(' ')+' Z';
}

// Axial offsets for pointy-top hex sides 0..5.
// Side i is the edge between corner i and corner (i+1)%6.
const SIDE_OFFSETS = {
  0: [ 1,  0],  // E
  1: [ 0,  1],  // SE
  2: [-1,  1],  // SW
  3: [-1,  0],  // W
  4: [ 0, -1],  // NW
  5: [ 1, -1],  // NE
};

// Vertex id: from hex + corner index (0..5). De-dupe by rounded position.
function vertexKey(x,y){ return Math.round(x)+':'+Math.round(y); }

// Build unique vertex and edge dicts from the 19 hex layout
function buildBoardGraph(tiles) {
  const vertices = {}; // key -> {id, x, y, hexes:[]}
  const edges = {};    // key -> {id, a, b, x1,y1,x2,y2}
  let vid = 0, eid = 0;
  tiles.forEach(t => {
    const corners = hexCorners(t.x, t.y);
    const vKeys = [];
    corners.forEach(([x,y]) => {
      const k = vertexKey(x,y);
      if (!vertices[k]) { vertices[k] = { id: vid++, key:k, x, y, hexes:[] }; }
      vertices[k].hexes.push(t.id);
      vKeys.push(k);
    });
    for (let i=0;i<6;i++){
      const a = vKeys[i], b = vKeys[(i+1)%6];
      const ekey = [a,b].sort().join('|');
      if (!edges[ekey]) {
        const va = vertices[a], vb = vertices[b];
        edges[ekey] = { id: eid++, key: ekey, a, b, x1: va.x, y1: va.y, x2: vb.x, y2: vb.y };
      }
    }
  });
  return { vertices, edges };
}

// Standard resources + number distribution (original, not Catan-branded artwork)
function makeStandardLayout(seed=1) {
  const resources = [
    'wood','wood','wood','wood',
    'sheep','sheep','sheep','sheep',
    'wheat','wheat','wheat','wheat',
    'brick','brick','brick',
    'ore','ore','ore',
    'desert'
  ];
  const numbers = [5,2,6,3,8,10,9,12,11,4,8,10,9,4,5,6,3,11];
  // simple seeded shuffle
  let s = seed;
  function rnd(){ s = (s*9301+49297)%233280; return s/233280; }
  function shuf(a){ a=a.slice(); for (let i=a.length-1;i>0;i--){ const j=Math.floor(rnd()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; }
  const res = shuf(resources);
  const nums = shuf(numbers);
  const tiles = [];
  let nIdx = 0;
  HEX_COORDS.forEach(([q,r], i) => {
    const { x, y } = axialToPx(q,r);
    const resource = res[i];
    const number = resource === 'desert' ? null : nums[nIdx++];
    tiles.push({ id: i, q, r, x, y, resource, number, hasRobber: resource === 'desert' });
  });
  return tiles;
}

// Probability pips for a number (classic: dots under the number)
function pipsFor(n){ return n ? Math.max(0, 6 - Math.abs(7 - n)) : 0; }

// ---------- HARBORS ----------
// Derive harbor positions from the actual coastal edges of the island. We walk the
// outer ring (tiles 0,1,2,6,11,18,17,16,12,7 form the perimeter ring on this layout)
// and place harbors on coastal sides in the canonical 9-harbor distribution.
const HARBOR_KINDS = ['3:1', 'sheep', '3:1', 'ore', 'wheat', '3:1', 'brick', '3:1', 'wood'];

function computeHarbors(tiles) {
  const byAxial = new Map();
  tiles.forEach(t => byAxial.set(t.q + ',' + t.r, t));
  const isCoastal = (t, side) => {
    const [dq, dr] = SIDE_OFFSETS[side];
    return !byAxial.has((t.q + dq) + ',' + (t.r + dr));
  };
  // Canonical perimeter tile order + preferred coastal side for each (clockwise from top-left).
  const PERIM = [
    { idx: 0, side: 5 },  // NE coast of top-left cap
    { idx: 2, side: 0 },  // E coast of top-right cap
    { idx: 6, side: 0 },
    { idx: 11, side: 1 },
    { idx: 18, side: 1 },
    { idx: 17, side: 2 },
    { idx: 16, side: 3 },
    { idx: 12, side: 3 },
    { idx: 7,  side: 4 },
  ];
  // P2-12: track assigned (tileIdx, side) pairs so fallbacks can't collide with a prior harbor.
  const used = new Set();
  return PERIM.map((p, i) => {
    const t = tiles[p.idx];
    let side = p.side;
    const sideKey = (s) => p.idx + ':' + s;
    const ok = (s) => isCoastal(t, s) && !used.has(sideKey(s));
    if (!ok(side)) {
      let found = false;
      for (let s = 0; s < 6; s++) if (ok(s)) { side = s; found = true; break; }
      if (!found) {
        // last resort: any coastal side, even if already used (should never happen on standard layout)
        for (let s = 0; s < 6; s++) if (isCoastal(t, s)) { side = s; break; }
      }
    }
    used.add(sideKey(side));
    return { tileIdx: p.idx, side, kind: HARBOR_KINDS[i] };
  });
}

// Resource visual defs
const RESOURCE_COLORS = {
  wood:   ['#4a7a3a','#2d5a2d','#1c3d1c'],
  sheep:  ['#a8d060','#8fb84a','#6a9130'],
  wheat:  ['#f2cc66','#e5b547','#b88a1d'],
  brick:  ['#e08040','#c2582c','#7a2c16'],
  ore:    ['#8a95a2','#6a7480','#474e58'],
  desert: ['#ecd29a','#d9bb7a','#a68650'],
};
const RESOURCE_LABEL = { wood:'FOREST', sheep:'PASTURE', wheat:'FIELD', brick:'HILLS', ore:'MOUNTAIN', desert:'DESERT' };

// Small emblem SVG per resource
function ResourceEmblem({ res, cx, cy }) {
  const common = { stroke:'rgba(0,0,0,.35)', strokeWidth:1 };
  const SC = 1.35;
  return (
    <g transform={`translate(${cx} ${cy}) scale(${SC})`} style={{pointerEvents:'none'}}>
      {res==='wood' && (
        <g opacity=".5">
          <path d="M 0 -26 L -12 -2 L -4 -2 L -14 18 L -5 18 L -14 30 L 14 30 L 5 18 L 14 18 L 4 -2 L 12 -2 Z" fill="#1c3d1c" {...common} />
          <path d="M 0 -26 L -6 -8 L -2 -8 L -7 8 L -3 8 L -7 18 L 7 18 L 3 8 L 7 8 L 2 -8 L 6 -8 Z" fill="#2d5a2d" opacity=".8" />
        </g>
      )}
      {res==='sheep' && (
        <g opacity=".65">
          <ellipse cx="0" cy="4" rx="22" ry="15" fill="#f0f0e8" stroke="#6a9130" strokeWidth="1.2"/>
          <circle cx="16" cy="-2" r="7" fill="#3a3a3a" />
          <circle cx="19" cy="-4" r="1.3" fill="#fff"/>
        </g>
      )}
      {res==='wheat' && (
        <g opacity=".55">
          {[-12,0,12].map((dx,i)=>(
            <g key={i} transform={`translate(${dx} 0)`}>
              <path d="M 0 -18 Q -5 -6 0 12 Q 5 -6 0 -18 Z" fill="#8a5a18" />
              <path d="M -5 -12 Q -2 -8 0 -6" stroke="#6d4510" strokeWidth="1.5" fill="none"/>
              <path d="M 5 -12 Q 2 -8 0 -6" stroke="#6d4510" strokeWidth="1.5" fill="none"/>
              <path d="M -6 -4 Q -2 0 0 2" stroke="#6d4510" strokeWidth="1.5" fill="none"/>
              <path d="M 6 -4 Q 2 0 0 2" stroke="#6d4510" strokeWidth="1.5" fill="none"/>
            </g>
          ))}
        </g>
      )}
      {res==='brick' && (
        <g opacity=".5">
          {[0,1,2].map(row=>(
            <g key={row} transform={`translate(${(row%2)*8 - 18} ${row*10 - 12})`}>
              <rect width="18" height="7" fill="#7a2c16" stroke="#4a1a0a" strokeWidth=".5" />
              <rect x="20" width="18" height="7" fill="#7a2c16" stroke="#4a1a0a" strokeWidth=".5" />
            </g>
          ))}
        </g>
      )}
      {res==='ore' && (
        <g opacity=".55">
          <path d="M -22 14 L -10 -8 L 4 -14 L 16 -4 L 22 14 Z" fill="#474e58" stroke="#2a2f36" strokeWidth="1"/>
          <path d="M -10 -8 L -4 4 L 4 -14" stroke="#8a95a2" strokeWidth="1.2" fill="none"/>
          <path d="M 4 -14 L 10 2 L 16 -4" stroke="#8a95a2" strokeWidth="1.2" fill="none"/>
        </g>
      )}
      {res==='desert' && (
        <g opacity=".7">
          {/* Clear sun w/ rays — reads even at a distance */}
          <circle cx="0" cy="0" r="10" fill="#c8953a" stroke="#7a5818" strokeWidth="1.2"/>
          {[0,1,2,3,4,5,6,7].map(i => {
            const a = i * Math.PI/4;
            const x1 = Math.cos(a)*14, y1 = Math.sin(a)*14;
            const x2 = Math.cos(a)*20, y2 = Math.sin(a)*20;
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
              stroke="#7a5818" strokeWidth="2" strokeLinecap="round"/>;
          })}
        </g>
      )}
    </g>
  );
}

// Hex tile render (painted wood with wood grain strokes) — memoized (P2-1)
const HexTile = React.memo(function HexTile({ tile, onClick, dim }) {
  const [c1,c2,c3] = RESOURCE_COLORS[tile.resource];
  const pathD = hexPath(tile.x, tile.y);
  const gid = `grad-${tile.id}`;
  return (
    <g className="hex-tile" style={{opacity: dim ? .75 : 1, pointerEvents:'none'}}>
      <defs>
        <linearGradient id={gid} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={c1} />
          <stop offset="55%" stopColor={c2} />
          <stop offset="100%" stopColor={c3} />
        </linearGradient>
        <clipPath id={`clip-${tile.id}`}>
          <path d={pathD} />
        </clipPath>
      </defs>
      {/* shadow ledge */}
      <path d={pathD} fill="rgba(0,0,0,.45)" transform={`translate(0 5)`} />
      {/* base paint */}
      <path d={pathD} fill={`url(#${gid})`} stroke="rgba(0,0,0,.35)" strokeWidth="1.2"/>
      {/* wood grain strokes (clipped) */}
      <g clipPath={`url(#clip-${tile.id})`} opacity=".35">
        {[...Array(6)].map((_,i)=>(
          <path key={i}
            d={`M ${tile.x-60} ${tile.y-40+i*14+((tile.id*3)%5)} Q ${tile.x} ${tile.y-38+i*14+((tile.id*7)%7)} ${tile.x+60} ${tile.y-40+i*14+((tile.id*11)%6)}`}
            stroke={c3} strokeWidth="1" fill="none" opacity={.5}
          />
        ))}
      </g>
      {/* highlight rim */}
      <path d={pathD} fill="none" stroke="rgba(255,255,255,.18)" strokeWidth="1" transform="translate(0 -1)"/>
      {/* emblem — faint watermark, top of tile so chit sits below uncluttered */}
      {tile.resource !== 'desert' && <ResourceEmblem res={tile.resource} cx={tile.x} cy={tile.y - 30} />}
      {tile.resource === 'desert' && <ResourceEmblem res="desert" cx={tile.x} cy={tile.y} />}
    </g>
  );
});

// Number chit — centered at hex center, larger pips for legibility (P2-1 memo, P2-3 pip offset fix)
const NumberChit = React.memo(function NumberChit({ cx, cy, number, highlighted, showPips=true }) {
  const pips = pipsFor(number);
  const isRed = number === 6 || number === 8;
  const redStroke = isRed ? { stroke:'#b91c1c', strokeWidth: 2 } : {};
  return (
    <g className="chit" style={{pointerEvents:'none'}}>
      <circle cx={cx} cy={cy+2} r="27" fill="rgba(0,0,0,.4)"/>
      <circle cx={cx} cy={cy} r="27" fill="#e4d4ae" {...(isRed ? redStroke : { stroke:'#8e7348', strokeWidth:1.5 })}/>
      <circle cx={cx} cy={cy} r="24" fill="url(#chit-grad)" />
      {/* P2-3: number stays centered at cy; pips live below as a separate baseline. */}
      <text x={cx} y={cy - (showPips ? 5 : 0)} textAnchor="middle" dominantBaseline="middle"
        fontFamily="'Cormorant Garamond', serif" fontWeight="700" fontSize="26"
        fill={isRed ? '#b91c1c' : '#1a1209'}>
        {number}
      </text>
      {showPips && (
        <g transform={`translate(${cx - (pips-1)*3.75} ${cy+15})`}>
          {[...Array(pips)].map((_,i)=>(
            <circle key={i} cx={i*7.5} cy={0} r={isRed?2.6:2.4}
              fill={isRed ? '#b91c1c' : '#1a1209'}
              stroke={isRed ? '#b91c1c' : 'none'} strokeWidth={isRed ? 0.6 : 0}/>
          ))}
        </g>
      )}
      {highlighted && (
        <circle className="chit-pulse" cx={cx} cy={cy} r="28" fill="none"
          stroke="#fff" strokeWidth="2.5"/>
      )}
    </g>
  );
});

// Settlement / City marks
function Settlement({ x, y, color, kind }) {
  const scale = kind === 'city' ? 1.8 : 1.4;
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`} style={{pointerEvents:'none'}}>
      <path d="M -10 4 L -10 -3 L 0 -11 L 10 -3 L 10 4 Z"
        fill={color} stroke="#1a1209" strokeWidth="1.4" strokeLinejoin="round"
        filter="url(#piece-shadow)" />
      {kind==='city' && (
        <path d="M 2 4 L 2 -4 L 12 -4 L 12 4 Z" fill={color} stroke="#1a1209" strokeWidth="1.4" strokeLinejoin="round" />
      )}
      <path d="M -10 -3 L 0 -11 L 10 -3" fill="none" stroke="rgba(255,255,255,.35)" strokeWidth="1" />
    </g>
  );
}

// Road rendered along an edge (P2-1 memo)
const Road = React.memo(function Road({ edge, color }) {
  const dx = edge.x2 - edge.x1, dy = edge.y2 - edge.y1;
  const len = Math.hypot(dx, dy);
  const ang = Math.atan2(dy, dx) * 180/Math.PI;
  const midX = (edge.x1+edge.x2)/2, midY = (edge.y1+edge.y2)/2;
  return (
    <g transform={`translate(${midX} ${midY}) rotate(${ang})`} style={{pointerEvents:'none'}}>
      <rect x={-len*.42} y={-6.5} width={len*.84} height={13} rx={2.5}
        fill={color} stroke="#1a1209" strokeWidth="1.4" filter="url(#piece-shadow)"/>
      <rect x={-len*.42} y={-6.5} width={len*.84} height={3} rx={1.5} fill="rgba(255,255,255,.3)" />
    </g>
  );
});

// Robber — sits upright on the hex center, no longer falling off the edge (P2-1 memo)
const Robber = React.memo(function Robber({ x, y }) {
  return (
    <g transform={`translate(${x} ${y}) scale(1.4)`} style={{pointerEvents:'none'}}>
      <ellipse cx="0" cy="12" rx="11" ry="3.5" fill="rgba(0,0,0,.55)" />
      <path d="M -9 8 C -9 -6 9 -6 9 8 Z" fill="#1a1209" stroke="#000" strokeWidth="1" />
      <circle cx="0" cy="-5" r="6.5" fill="#1a1209" stroke="#000" strokeWidth="1" />
      <circle cx="-2" cy="-6" r=".9" fill="#c73a2e" />
      <circle cx="2" cy="-6" r=".9" fill="#c73a2e" />
    </g>
  );
});

// Harbor (little dock on coast) — P2-1 memo, P2-2 larger chip
const Harbor = React.memo(function Harbor({ tile, side, kind }) {
  // midpoint-of-side angle for pointy-top: 60*side
  const ang = (60*side) * Math.PI/180;
  const ox = tile.x + Math.cos(ang) * (HEX_SIZE * 1.15);
  const oy = tile.y + Math.sin(ang) * (HEX_SIZE * 1.15);
  const corners = hexCorners(tile.x, tile.y);
  const c1 = corners[side], c2 = corners[(side+1)%6];
  const label = kind === '3:1' ? '3:1' : '2:1';
  const kindColor = {
    '3:1': '#f4e8c8', wood:'#2d5a2d', sheep:'#8fb84a', wheat:'#e5b547', brick:'#b34a2a', ore:'#6a7480'
  }[kind];
  return (
    <g style={{pointerEvents:'none'}}>
      <line x1={c1[0]} y1={c1[1]} x2={ox} y2={oy} stroke="#6b4a24" strokeWidth="2.5" opacity=".9"/>
      <line x1={c2[0]} y1={c2[1]} x2={ox} y2={oy} stroke="#6b4a24" strokeWidth="2.5" opacity=".9"/>
      <circle cx={ox} cy={oy} r="17" fill="#3a2614" stroke="#8e7348" strokeWidth="1.5"/>
      <circle cx={ox} cy={oy} r="14" fill={kindColor} opacity=".95" stroke="#1a1209" strokeWidth=".8"/>
      <text x={ox} y={oy+1} textAnchor="middle" dominantBaseline="middle"
        fontFamily="'IBM Plex Mono', monospace" fontSize={kind==='3:1'?10:11} fontWeight="700"
        fill={kind==='3:1' ? '#1a1209' : (kind==='wheat'?'#2b1d00':'#fff')}>{label}</text>
    </g>
  );
});

// ---------- LEGAL-VERTEX FILTER ----------
function legalSettlementVertices(vertices, vertexNeighbors, settlements, cities, requireOwnRoad, playerId, roads) {
  const occupied = new Set([...Object.keys(settlements), ...Object.keys(cities)]);
  const blocked = new Set();
  for (const oid of occupied) {
    blocked.add(oid);
    for (const n of (vertexNeighbors[oid] || [])) blocked.add(n.vKey);
  }
  return new Set(Object.keys(vertices).filter(id => {
    if (blocked.has(id)) return false;
    if (requireOwnRoad) {
      const touchesOwnRoad = (vertexNeighbors[id] || []).some(n => roads[n.eKey]?.playerId === playerId);
      if (!touchesOwnRoad) return false;
    }
    return true;
  }));
}

function legalCityVertices(settlements, playerId) {
  return new Set(Object.entries(settlements)
    .filter(([, o]) => o.playerId === playerId)
    .map(([k]) => k));
}

// Rule 23: Longest-road length per player. An opponent's settlement/city on a vertex
// BREAKS a road chain — you can't traverse through it. Not yet wired into scoring,
// but callable as `computeLongestRoad(roads, edges, vertexNeighbors, settlements, cities, playerId)`.
function computeLongestRoad(roads, edges, vertexNeighbors, settlements, cities, playerId) {
  const ownEdges = Object.keys(roads).filter(k => roads[k].playerId === playerId);
  if (!ownEdges.length) return 0;
  // Vertex is blocked for THIS player iff an opponent has a building there.
  const isBlocked = (v) => {
    const s = settlements[v]?.playerId;
    const c = cities[v]?.playerId;
    return (s && s !== playerId) || (c && c !== playerId);
  };
  let best = 0;
  // DFS from each endpoint of each owned edge; don't reuse the same edge.
  const edgeByKey = edges;
  function dfs(atVertex, used) {
    if (used.size > best) best = used.size;
    if (isBlocked(atVertex)) return; // can't continue through opponent building
    for (const n of (vertexNeighbors[atVertex] || [])) {
      if (used.has(n.eKey)) continue;
      if (!roads[n.eKey] || roads[n.eKey].playerId !== playerId) continue;
      used.add(n.eKey);
      dfs(n.vKey, used);
      used.delete(n.eKey);
    }
  }
  for (const ek of ownEdges) {
    const e = edgeByKey[ek]; if (!e) continue;
    for (const start of [e.a, e.b]) {
      const used = new Set([ek]);
      // Starting at `start` means we just traversed ek, sitting at `start`.
      dfs(start, used);
    }
  }
  return best;
}

function legalRoadEdges(edges, vertexNeighbors, settlements, cities, roads, playerId, anchorVertex) {
  const legal = new Set();
  for (const e of Object.values(edges)) {
    if (roads[e.key]) continue;
    if (anchorVertex) {
      if (e.a === anchorVertex || e.b === anchorVertex) legal.add(e.key);
      continue;
    }
    const touchesOwnBuilding = [e.a, e.b].some(v =>
      settlements[v]?.playerId === playerId || cities[v]?.playerId === playerId);
    if (touchesOwnBuilding) { legal.add(e.key); continue; }
    const touchesOwnRoadAt = (v) => {
      if (settlements[v]?.playerId && settlements[v].playerId !== playerId) return false; // opponent blocks
      return (vertexNeighbors[v] || []).some(n => n.eKey !== e.key && roads[n.eKey]?.playerId === playerId);
    };
    if (touchesOwnRoadAt(e.a) || touchesOwnRoadAt(e.b)) legal.add(e.key);
  }
  return legal;
}

// Build vertex adjacency from edges (shared helper so Board can compute legality locally)
function buildVertexNeighbors(edges) {
  const map = {};
  for (const e of Object.values(edges)) {
    (map[e.a] = map[e.a] || []).push({ vKey: e.b, eKey: e.key });
    (map[e.b] = map[e.b] || []).push({ vKey: e.a, eKey: e.key });
  }
  return map;
}

// -------------- Main Board component --------------
function Board({ state, onVertexClick, onEdgeClick, onHexClick, highlightedNumber, phase, currentPlayer, turn, showPips=true }) {
  const { tiles, vertices, edges, settlements, cities, roads, robberHex } = state;

  const showVertexSpots = phase === 'placeSettlement1' || phase === 'placeSettlement2' || phase === 'buildSettlement' || phase === 'buildCity';
  const showEdgeSpots   = phase === 'placeRoad1' || phase === 'placeRoad2' || phase === 'buildRoad';
  const showRobberSpots = phase === 'moveRobber';

  const pColor = currentPlayer ? currentPlayer.rawColor : '#fff';
  const pId    = currentPlayer ? currentPlayer.id : null;

  const vertexNeighbors = useMemo(() => buildVertexNeighbors(edges), [edges]);
  const harbors = useMemo(() => computeHarbors(tiles), [tiles]);

  const legalVerts = useMemo(() => {
    if (!showVertexSpots || !pId) return new Set();
    if (phase === 'buildCity') return legalCityVertices(settlements, pId);
    const requireRoad = phase === 'buildSettlement';
    return legalSettlementVertices(vertices, vertexNeighbors, settlements, cities, requireRoad, pId, roads);
  }, [showVertexSpots, phase, pId, vertices, vertexNeighbors, settlements, cities, roads]);

  // Build legal edge set. Setup phases are anchored to the most recent un-roaded settlement.
  const pendingAnchor = useMemo(() => {
    if (phase !== 'placeRoad1' && phase !== 'placeRoad2') return null;
    if (!pId) return null;
    // find the player's settlement(s) without any owned road attached, pick the one just placed
    // P1-5: use placedAt timestamp rather than iteration order.
    const candidates = Object.entries(settlements)
      .filter(([, o]) => o.playerId === pId)
      .filter(([vKey]) => !(vertexNeighbors[vKey] || []).some(n => roads[n.eKey]?.playerId === pId))
      .sort((a, b) => (b[1].placedAt || 0) - (a[1].placedAt || 0));
    return candidates.length ? candidates[0][0] : null;
  }, [phase, pId, settlements, roads, vertexNeighbors]);

  const legalEdges = useMemo(() => {
    if (!showEdgeSpots || !pId) return new Set();
    return legalRoadEdges(edges, vertexNeighbors, settlements, cities, roads, pId, pendingAnchor);
  }, [showEdgeSpots, pId, edges, vertexNeighbors, settlements, cities, roads, pendingAnchor]);

  return (
    <svg viewBox="40 60 920 900" preserveAspectRatio="xMidYMid meet"
      aria-labelledby="katan-title" aria-describedby="katan-desc">
      <title id="katan-title">Katan board</title>
      <desc id="katan-desc">Round {turn || 1} — {phase}</desc>
      <defs>
        <radialGradient id="chit-grad" cx="50%" cy="35%" r="65%">
          <stop offset="0%" stopColor="#f7eccc" />
          <stop offset="100%" stopColor="#e1cfa1" />
        </radialGradient>
        <radialGradient id="ocean-grad" cx="50%" cy="50%" r="60%">
          <stop offset="0%" stopColor="#2d7087" />
          <stop offset="70%" stopColor="#1f5566" />
          <stop offset="100%" stopColor="#0f3341" />
        </radialGradient>
        <filter id="piece-shadow" x="-50%" y="-50%" width="200%" height="200%">
          <feDropShadow dx="0" dy="1.5" stdDeviation="1.2" floodOpacity=".5"/>
        </filter>
        <filter id="board-shadow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="6" stdDeviation="10" floodOpacity=".45"/>
        </filter>
        <pattern id="waves" x="0" y="0" width="40" height="20" patternUnits="userSpaceOnUse">
          <path d="M 0 10 Q 10 4 20 10 T 40 10" stroke="rgba(255,255,255,.06)" strokeWidth="1.2" fill="none"/>
          <path d="M 0 16 Q 10 10 20 16 T 40 16" stroke="rgba(255,255,255,.04)" strokeWidth="1" fill="none"/>
        </pattern>
      </defs>

      {/* Ocean hex frame — larger radius so island fully fits with margin */}
      <g filter="url(#board-shadow)">
        {(() => {
          const R = HEX_SIZE * 4.6;
          const pts = [];
          for (let i=0;i<6;i++){
            const a = Math.PI/180 * (60*i - 30);
            pts.push([BOARD_CX + R*Math.cos(a), BOARD_CY + R*Math.sin(a)]);
          }
          const d = pts.map(([x,y],i)=>(i?'L':'M')+x.toFixed(1)+' '+y.toFixed(1)).join(' ')+' Z';

          // Inner inset ocean — pre-computed, not CSS-transformed
          const innerScale = 0.955;
          const innerPts = pts.map(([x,y]) => [
            BOARD_CX + (x - BOARD_CX) * innerScale,
            BOARD_CY + (y - BOARD_CY) * innerScale,
          ]);
          const dInner = innerPts.map(([x,y],i)=>(i?'L':'M')+x.toFixed(1)+' '+y.toFixed(1)).join(' ')+' Z';
          return <g>
            <path d={d} fill="#6b4a24" stroke="#3a2614" strokeWidth="3"
              transform={`translate(0 6)`} opacity=".55"/>
            <path d={d} fill="#6b4a24" stroke="#3a2614" strokeWidth="3"/>
            <path d={dInner} fill="url(#ocean-grad)"/>
            <path d={dInner} fill="url(#waves)"/>
          </g>;
        })()}
      </g>

      {/* Harbors */}
      {harbors.map((h, i) => (
        <Harbor key={i} tile={tiles[h.tileIdx]} side={h.side} kind={h.kind}/>
      ))}

      {/* Hex tiles */}
      {tiles.map(t => (
        <HexTile key={t.id} tile={t}
          dim={highlightedNumber != null && t.number !== highlightedNumber} />
      ))}

      {/* Hex click spots (for robber) */}
      {showRobberSpots && tiles.map(t => (
        <g key={'rs'+t.id} className="robber-spot"
          role="button" tabIndex={0}
          aria-label={`Move robber to ${RESOURCE_LABEL[t.resource]}${t.number?' '+t.number:''}`}
          onClick={() => onHexClick(t.id)}
          onKeyDown={e => { if (e.key==='Enter'||e.key===' ') { e.preventDefault(); onHexClick(t.id); }}}>
          <circle cx={t.x} cy={t.y} r={HEX_SIZE*.8}
            fill="rgba(255,255,255,.08)" stroke="#fff" strokeWidth="2" strokeDasharray="4 4"
            style={{cursor:'pointer'}}/>
        </g>
      ))}

      {/* Number chits — centered at hex center */}
      {tiles.map(t => t.number != null && (
        <NumberChit key={'c'+t.id} cx={t.x} cy={t.y} number={t.number}
          highlighted={highlightedNumber === t.number}
          showPips={showPips}/>
      ))}

      {/* Roads */}
      {Object.entries(roads).map(([eKey, owner]) => {
        const edge = edges[eKey];
        if (!edge) return null;
        return <Road key={'r'+eKey} edge={edge} color={owner.color}/>;
      })}

      {/* Edge placement spots */}
      {showEdgeSpots && [...legalEdges].map(eKey => {
        const e = edges[eKey];
        return (
          <g key={'es'+e.key} className="edge-spot"
            role="button" tabIndex={0}
            aria-label="Place road here"
            onClick={() => onEdgeClick(e.key)}
            onKeyDown={ev => { if (ev.key==='Enter'||ev.key===' ') { ev.preventDefault(); onEdgeClick(e.key); }}}>
            <line x1={e.x1} y1={e.y1} x2={e.x2} y2={e.y2}
              stroke={pColor} strokeWidth="10" strokeLinecap="round" opacity=".55"/>
            <line x1={e.x1} y1={e.y1} x2={e.x2} y2={e.y2}
              stroke="#fff" strokeWidth="1.8" strokeDasharray="4 4" opacity=".85"/>
          </g>
        );
      })}

      {/* Settlements / cities */}
      {Object.entries(settlements).map(([vKey, owner]) => {
        const v = vertices[vKey];
        return <Settlement key={'s'+vKey} x={v.x} y={v.y} color={owner.color} kind="settlement"/>;
      })}
      {Object.entries(cities).map(([vKey, owner]) => {
        const v = vertices[vKey];
        return <Settlement key={'ct'+vKey} x={v.x} y={v.y} color={owner.color} kind="city"/>;
      })}

      {/* Vertex placement spots — only legal ones. P1-1: roving tabindex + arrow-key nav. */}
      {showVertexSpots && (() => {
        const list = [...legalVerts];
        return list.map((vKey, i) => {
          const v = vertices[vKey];
          const label = phase === 'buildCity' ? 'Upgrade to city' : 'Place settlement';
          const onKey = (e) => {
            if (e.key==='Enter'||e.key===' ') { e.preventDefault(); onVertexClick(v.key); return; }
            // Arrow keys: move focus to the geographically-nearest legal spot in that direction.
            const dirs = { ArrowRight:[1,0], ArrowLeft:[-1,0], ArrowDown:[0,1], ArrowUp:[0,-1] };
            const d = dirs[e.key];
            if (!d) return;
            e.preventDefault();
            let best = -1, bestScore = Infinity;
            list.forEach((otherK, j) => {
              if (j === i) return;
              const o = vertices[otherK];
              const dx = o.x - v.x, dy = o.y - v.y;
              const along = dx*d[0] + dy*d[1];
              if (along <= 0) return;
              const perp = Math.abs(dx*d[1] - dy*d[0]);
              const score = perp * 2 - along * .3;
              if (score < bestScore) { bestScore = score; best = j; }
            });
            if (best >= 0) {
              const el = document.querySelector(`[data-vspot="${list[best]}"]`);
              if (el) el.focus();
            }
          };
          return (
            <g key={'vs'+v.key} className="vertex-spot"
              data-vspot={v.key}
              role="button" tabIndex={i === 0 ? 0 : -1}
              aria-label={label}
              onClick={() => onVertexClick(v.key)}
              onKeyDown={onKey}>
              <circle className="vertex-spot-ring" cx={v.x} cy={v.y} r="17" fill="none" stroke={pColor} strokeWidth="1.4"/>
              <circle cx={v.x} cy={v.y} r="13" fill={pColor} opacity=".75" stroke="#fff" strokeWidth="1.8"/>
            </g>
          );
        });
      })()}

      {/* Robber */}
      {robberHex != null && (() => {
        const t = tiles[robberHex];
        return <Robber x={t.x} y={t.y}/>;
      })()}
    </svg>
  );
}

// Expose
Object.assign(window, {
  Board, makeStandardLayout, buildBoardGraph, buildVertexNeighbors, axialToPx,
  HEX_COORDS, RESOURCE_LABEL, pipsFor, hexCorners,
  legalSettlementVertices, legalCityVertices, legalRoadEdges,
  computeLongestRoad,
});
