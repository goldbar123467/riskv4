// Top-level game logic
const { useState, useEffect, useMemo, useRef } = React;

const PLAYERS_INIT = [
  { id:'p1', name:'You',     color:'var(--p1)', rawColor:'#e07b1c', isHuman:true  },
  { id:'p2', name:'Albrecht',color:'var(--p2)', rawColor:'#8a1f1a', isHuman:false },
  { id:'p3', name:'Mira',    color:'var(--p3)', rawColor:'#2c6ea0', isHuman:false },
  { id:'p4', name:'Jules',   color:'var(--p4)', rawColor:'#2e7d4a', isHuman:false },
];

function freshPlayers() {
  return PLAYERS_INIT.map(p => ({
    ...p,
    color: p.rawColor,
    vp: 0,
    res: { wood:0, brick:0, wheat:0, sheep:0, ore:0 },
    dev: 0, devList: [],
    settlementsLeft: 5, citiesLeft: 4, roadsLeft: 15,
  }));
}

function useLS(key, initial, { debounce = false } = {}) {
  const [v, setV] = useState(() => {
    try { const raw = localStorage.getItem(key); if (raw) return JSON.parse(raw); } catch(e){}
    return initial;
  });
  useEffect(()=>{
    if (debounce) writeLSDebounced(key, v);
    else { try { localStorage.setItem(key, JSON.stringify(v)); } catch(e){} }
  }, [key, v]);
  return [v, setV];
}

const STARTING_PHASE_SEQ = ['placeSettlement1','placeRoad1','placeSettlement2','placeRoad2'];

// Shared phase predicate (extracted per P2-14).
function isSetupPhase(p) {
  return p === 'placeSettlement1' || p === 'placeSettlement2'
      || p === 'placeRoad1' || p === 'placeRoad2';
}

// Layout version. Bump to invalidate all layout-dependent LS state (P0-2).
const LAYOUT_VERSION = 'v2';
function layoutKey(seed) { return `katan.layout-${seed}-${LAYOUT_VERSION}`; }

// LS janitor: remove any katan.layout-* keys that don't match the current layoutKey.
function purgeStaleLayoutKeys(currentLayoutKey) {
  try {
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const k = localStorage.key(i);
      if (!k) continue;
      if (k.startsWith('katan.layout-') && !k.startsWith(currentLayoutKey + '.')) {
        localStorage.removeItem(k);
      }
    }
  } catch (e) {}
}

// Debounced LS writer (P2-11). Coalesces rapid writes into one per key.
const __lsQueue = new Map();
function writeLSDebounced(key, value, delay = 200) {
  if (__lsQueue.has(key)) clearTimeout(__lsQueue.get(key));
  __lsQueue.set(key, setTimeout(() => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) {}
    __lsQueue.delete(key);
  }, delay));
}

function App() {
  // Board state
  const [seed, setSeed] = useLS('katan.seed', 17);
  const tiles = useMemo(() => makeStandardLayout(seed), [seed]);
  const graph = useMemo(() => buildBoardGraph(tiles), [tiles]);

  // Layout-dependent state is namespaced by seed + layout version (P0-2).
  const LK = useMemo(() => layoutKey(seed), [seed]);
  useEffect(() => { purgeStaleLayoutKeys(LK); }, [LK]);

  const desertIdx = useMemo(() => tiles.findIndex(t => t.resource === 'desert'), [tiles]);

  const [players, setPlayers] = useLS('katan.players', freshPlayers(), { debounce: true });
  const [settlements, setSettlements] = useLS(`${LK}.settlements`, {}, { debounce: true }); // vKey -> {playerId, color, placedAt}
  const [cities, setCities]           = useLS(`${LK}.cities`, {}, { debounce: true });
  const [roads, setRoads]             = useLS(`${LK}.roads`, {}, { debounce: true }); // eKey -> {playerId, color, placedAt}
  const [robberHex, setRobberHex]     = useLS(`${LK}.robber`, desertIdx);

  // P0-1: validate robber position on layout change — if desert moved and no settlements placed yet, reset.
  useEffect(() => {
    if (tiles[robberHex]?.resource !== 'desert' && Object.keys(settlements).length === 0) {
      setRobberHex(desertIdx);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [desertIdx]);

  const [turn, setTurn] = useLS('katan.turn', 1);
  const [currentPlayerIdx, setCurrentPlayerIdx] = useLS('katan.cp', 0);
  const [phase, setPhase] = useLS('katan.phase', 'placeSettlement1');
  const [setupStep, setSetupStep] = useLS('katan.setupStep', 0);
  const [setupDir, setSetupDir] = useLS('katan.setupDir', 1);
  const [pendingSettlement, setPendingSettlement] = useLS('katan.pendS', null);

  const [dice, setDice] = useLS('katan.dice', [1,1]);
  const [rolling, setRolling] = useState(false);
  const [highlightedNumber, setHighlightedNumber] = useState(null);

  const [log, setLog] = useLS('katan.log', [
    { turn:1, text:'A new isle rises from the sea. Place your first settlement.' }
  ]);
  const [toast, setToast] = useState(null);
  const toastTimer = useRef();

  const [tradeSel, setTradeSel] = useState({ give:'', get:'' });
  // Rule 21: victim-selection dialog state.
  const [victimChoice, setVictimChoice] = useState(null); // string[] of playerIds or null

  // --- tweaks ---
  const [tweaks, setTweaks] = useState(() => {
    try { return JSON.parse(localStorage.getItem('katan.tweaks')) || {}; } catch(e){ return {}; }
  });
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "boardTheme": "walnut",
    "panelTheme": "parchment",
    "showPips": true,
    "aiSpeed": 900
  }/*EDITMODE-END*/;
  const merged = { ...TWEAK_DEFAULTS, ...tweaks };

  // P2-9: only expose tweaks message plumbing when dev flag is on (?tweaks=1 or localhost).
  const tweaksEnabled = useMemo(() => {
    try {
      if (new URLSearchParams(location.search).has('tweaks')) return true;
      return ['localhost', '127.0.0.1'].includes(location.hostname);
    } catch (e) { return false; }
  }, []);

  // tweaks message handling
  useEffect(()=>{
    if (!tweaksEnabled) return;
    const handler = (e) => {
      if (!e.data || typeof e.data !== 'object') return;
      if (e.data.type === '__activate_edit_mode') setEditMode(true);
      if (e.data.type === '__deactivate_edit_mode') setEditMode(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return ()=> window.removeEventListener('message', handler);
  },[tweaksEnabled]);
  const [editMode, setEditMode] = useState(false);

  function updateTweak(k, v) {
    const next = { ...tweaks, [k]: v };
    setTweaks(next);
    try { localStorage.setItem('katan.tweaks', JSON.stringify(next)); } catch(e){}
    window.parent.postMessage({ type:'__edit_mode_set_keys', edits:{ [k]: v } }, '*');
  }

  // --- helpers ---
  function showToast(msg, ms=1800) {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(()=> setToast(null), ms);
  }
  function pushLog(text) {
    setLog(l => [...l.slice(-40), { turn, text }]);
  }

  const currentPlayer = players[currentPlayerIdx];
  const nextPlayerIdx = (currentPlayerIdx + 1) % players.length;

  // Vertex/edge adjacency helpers
  const vertexNeighbors = useMemo(()=>{
    const map = {};
    Object.values(graph.edges).forEach(e => {
      map[e.a] = map[e.a] || []; map[e.a].push({ vKey: e.b, eKey: e.key });
      map[e.b] = map[e.b] || []; map[e.b].push({ vKey: e.a, eKey: e.key });
    });
    return map;
  },[graph]);

  function vertexHasBuilding(vKey) { return !!settlements[vKey] || !!cities[vKey]; }

  function isTooClose(vKey) {
    const nbrs = vertexNeighbors[vKey] || [];
    return nbrs.some(n => vertexHasBuilding(n.vKey));
  }

  function playerHasAdjacentRoad(vKey, playerId) {
    const nbrs = vertexNeighbors[vKey] || [];
    return nbrs.some(n => roads[n.eKey] && roads[n.eKey].playerId === playerId);
  }

  function edgeEndpoints(eKey){ return [graph.edges[eKey].a, graph.edges[eKey].b]; }

  function canPlaceRoadAtEdge(eKey, playerId, opts={}) {
    if (roads[eKey]) return false;
    const [a,b] = edgeEndpoints(eKey);
    // Must connect to own building or own road
    const hasOwnBuilding = (settlements[a]?.playerId===playerId) || (settlements[b]?.playerId===playerId)
      || (cities[a]?.playerId===playerId) || (cities[b]?.playerId===playerId);
    if (opts.anchorVertex) {
      return (a === opts.anchorVertex || b === opts.anchorVertex) && !roads[eKey];
    }
    if (hasOwnBuilding) return true;
    // adjacent road owned by player
    const connects = (vKey) => (vertexNeighbors[vKey]||[]).some(n => n.eKey !== eKey && roads[n.eKey]?.playerId === playerId);
    // but not through an opponent's settlement
    if (settlements[a]?.playerId && settlements[a].playerId!==playerId) {} else if (connects(a)) return true;
    if (settlements[b]?.playerId && settlements[b].playerId!==playerId) {} else if (connects(b)) return true;
    return false;
  }

  // ---------- SETUP PLACEMENTS ----------
  function handleVertexClick(vKey) {
    if (phase === 'placeSettlement1' || phase === 'placeSettlement2') {
      if (vertexHasBuilding(vKey)) return showToast('Spot taken');
      if (isTooClose(vKey))       return showToast('Too close to another settlement');
      setSettlements({ ...settlements, [vKey]: { playerId: currentPlayer.id, color: currentPlayer.rawColor, placedAt: Date.now() } });
      setPendingSettlement(vKey);
      setPlayers(players.map((p,i)=> i===currentPlayerIdx ? { ...p, vp: p.vp + 1, settlementsLeft: p.settlementsLeft-1 } : p));
      // On second settlement, grant starting resources
      if (phase === 'placeSettlement2') {
        const v = graph.vertices[vKey];
        const gained = { wood:0, brick:0, wheat:0, sheep:0, ore:0 };
        v.hexes.forEach(hid => {
          const t = tiles[hid];
          if (t.resource !== 'desert') gained[t.resource]++;
        });
        const gainedTxt = Object.entries(gained).filter(([,n])=>n>0).map(([r,n])=>`${n} ${r}`).join(', ');
        if (gainedTxt) {
          setPlayers(prev => prev.map((p,i)=> i===currentPlayerIdx ? {
            ...p, vp: p.vp + 1, settlementsLeft: p.settlementsLeft - 1,
            res: Object.fromEntries(Object.entries(p.res).map(([k,v])=>[k, v+gained[k]]))
          } : p));
          pushLog(`${currentPlayer.name} founded a settlement and collected ${gainedTxt}.`);
        } else {
          pushLog(`${currentPlayer.name} founded a settlement in the desert.`);
        }
      } else {
        pushLog(`${currentPlayer.name} placed their first settlement.`);
      }
      setPhase(phase === 'placeSettlement1' ? 'placeRoad1' : 'placeRoad2');
      return;
    }

    if (phase === 'buildSettlement') {
      if (vertexHasBuilding(vKey)) return showToast('Spot taken');
      if (isTooClose(vKey))        return showToast('Too close to another settlement');
      if (!playerHasAdjacentRoad(vKey, currentPlayer.id)) return showToast('Must connect to your road');
      setSettlements({ ...settlements, [vKey]: { playerId: currentPlayer.id, color: currentPlayer.rawColor } });
      setPlayers(players.map((p,i)=> i===currentPlayerIdx ? {
        ...p, vp: p.vp+1, settlementsLeft: p.settlementsLeft-1,
        res: { ...p.res, wood:p.res.wood-1, brick:p.res.brick-1, wheat:p.res.wheat-1, sheep:p.res.sheep-1 }
      } : p));
      pushLog(`${currentPlayer.name} built a settlement.`);
      setPhase('rolled');
      return;
    }
    if (phase === 'buildCity') {
      if (settlements[vKey]?.playerId !== currentPlayer.id) return showToast('Upgrade one of your settlements');
      const newS = { ...settlements }; delete newS[vKey];
      setSettlements(newS);
      setCities({ ...cities, [vKey]: { playerId: currentPlayer.id, color: currentPlayer.rawColor } });
      setPlayers(players.map((p,i)=> i===currentPlayerIdx ? {
        ...p, vp: p.vp+1, settlementsLeft: p.settlementsLeft+1, citiesLeft: p.citiesLeft-1,
        res: { ...p.res, wheat: p.res.wheat-2, ore: p.res.ore-3 }
      } : p));
      pushLog(`${currentPlayer.name} upgraded to a city.`);
      setPhase('rolled');
      return;
    }
  }

  function handleEdgeClick(eKey) {
    if (phase === 'placeRoad1' || phase === 'placeRoad2') {
      if (!canPlaceRoadAtEdge(eKey, currentPlayer.id, { anchorVertex: pendingSettlement })) return showToast('Must touch your settlement');
      setRoads({ ...roads, [eKey]: { playerId: currentPlayer.id, color: currentPlayer.rawColor } });
      setPlayers(players.map((p,i)=> i===currentPlayerIdx ? { ...p, roadsLeft: p.roadsLeft-1 } : p));
      pushLog(`${currentPlayer.name} laid a road.`);
      setPendingSettlement(null);
      advanceSetup();
      return;
    }
    if (phase === 'buildRoad') {
      if (!canPlaceRoadAtEdge(eKey, currentPlayer.id)) return showToast('Must connect to your network');
      setRoads({ ...roads, [eKey]: { playerId: currentPlayer.id, color: currentPlayer.rawColor } });
      setPlayers(players.map((p,i)=> i===currentPlayerIdx ? {
        ...p, roadsLeft: p.roadsLeft-1,
        res: { ...p.res, wood: p.res.wood-1, brick: p.res.brick-1 }
      } : p));
      pushLog(`${currentPlayer.name} built a road.`);
      setPhase('rolled');
      return;
    }
  }

  function handleHexClick(hexId) {
    if (phase !== 'moveRobber') return;
    if (hexId === robberHex) return showToast('Robber must move');
    setRobberHex(hexId);
    pushLog(`${currentPlayer.name} moved the robber.`);
    // Rule 21: find opponents with settlement/city on this hex's corners → victim selection.
    const t = tiles[hexId];
    const victims = new Set();
    hexCorners(t.x, t.y).forEach(([x,y]) => {
      const key = Math.round(x)+':'+Math.round(y);
      const owner = settlements[key]?.playerId || cities[key]?.playerId;
      if (owner && owner !== currentPlayer.id) {
        const vp = players.find(p => p.id === owner);
        if (vp && Object.values(vp.res).reduce((a,b)=>a+b,0) > 0) victims.add(owner);
      }
    });
    if (victims.size === 0) { setPhase('rolled'); return; }
    if (victims.size === 1) { stealFrom([...victims][0]); setPhase('rolled'); return; }
    setVictimChoice([...victims]);
    setPhase('rolled');
  }

  // Rule 21: steal one random resource from the chosen victim.
  function stealFrom(victimId) {
    const victim = players.find(p => p.id === victimId);
    if (!victim) return;
    const pool = [];
    Object.entries(victim.res).forEach(([k,n]) => { for (let i=0;i<n;i++) pool.push(k); });
    if (!pool.length) return;
    const stolen = pool[Math.floor(Math.random()*pool.length)];
    setPlayers(prev => prev.map(p => {
      if (p.id === victimId) return { ...p, res: { ...p.res, [stolen]: p.res[stolen]-1 } };
      if (p.id === currentPlayer.id) return { ...p, res: { ...p.res, [stolen]: p.res[stolen]+1 } };
      return p;
    }));
    pushLog(`${currentPlayer.name} stole a ${stolen} from ${victim.name}.`);
    setVictimChoice(null);
  }

  function advanceSetup() {
    // Snake order: 0,1,2,3,3,2,1,0
    const step = setupStep + 1;
    setSetupStep(step);
    const totalPlayers = players.length;
    const totalSetup = totalPlayers * 2;
    if (step >= totalSetup) {
      // Setup done, begin turn 1 with player 0
      setSetupDir(1);
      setCurrentPlayerIdx(0);
      setPhase('idle');
      setTurn(1);
      pushLog(`Setup complete. ${players[0].name} begins the first turn.`);
      return;
    }
    // Compute next player using snake sequence
    let order = [];
    for (let i=0;i<totalPlayers;i++) order.push(i);
    const snake = order.concat([...order].reverse());
    const nextIdx = snake[step];
    setCurrentPlayerIdx(nextIdx);
    setPhase(step < totalPlayers ? 'placeSettlement1' : 'placeSettlement2');
    if (!players[nextIdx].isHuman) {
      // queue AI placement
      setTimeout(()=> aiSetupPlace(nextIdx, step < totalPlayers ? 1 : 2), merged.aiSpeed);
    }
  }

  // AI setup placements (simple greedy: score by number pips on adjacent hexes)
  function aiSetupPlace(pIdx, round) {
    // pick best vertex
    const available = Object.values(graph.vertices).filter(v => !vertexHasBuilding(v.key) && !isTooClose(v.key));
    const scored = available.map(v => {
      let s = 0;
      v.hexes.forEach(hid => {
        const t = tiles[hid];
        if (t.number) s += pipsFor(t.number);
      });
      return { v, s };
    }).sort((a,b)=> b.s - a.s);
    if (!scored.length) { advanceSetup(); return; }
    const chosen = scored[0].v;
    const playerId = players[pIdx].id;
    const color = players[pIdx].rawColor;
    setSettlements(prev => ({ ...prev, [chosen.key]: { playerId, color } }));
    setPlayers(prev => prev.map((p,i)=> {
      if (i !== pIdx) return p;
      let res = { ...p.res };
      if (round === 2) {
        chosen.hexes.forEach(hid => {
          const t = tiles[hid];
          if (t.resource !== 'desert') res[t.resource]++;
        });
      }
      return { ...p, vp: p.vp+1, settlementsLeft: p.settlementsLeft-1, res };
    }));
    pushLog(`${players[pIdx].name} ${round===2?'founded':'placed'} a settlement.`);
    // pick best adjacent edge
    const nbrs = vertexNeighbors[chosen.key] || [];
    const freeEdge = nbrs.map(n=>n.eKey).find(ek => !roads[ek]);
    if (freeEdge) {
      setRoads(prev => ({ ...prev, [freeEdge]: { playerId, color } }));
      setPlayers(prev => prev.map((p,i)=> i===pIdx ? { ...p, roadsLeft: p.roadsLeft-1 } : p));
      pushLog(`${players[pIdx].name} laid a road.`);
    }
    setTimeout(advanceSetup, 300);
  }

  // ---------- DICE ROLL ----------
  function rollDice() {
    if (phase !== 'idle') return;
    setRolling(true);
    let frames = 0;
    const tickT = setInterval(()=> {
      setDice([1+Math.floor(Math.random()*6), 1+Math.floor(Math.random()*6)]);
      frames++;
      if (frames > 8) {
        clearInterval(tickT);
        const a = 1+Math.floor(Math.random()*6), b = 1+Math.floor(Math.random()*6);
        setDice([a,b]);
        setRolling(false);
        resolveRoll(a+b);
      }
    }, 70);
  }

  function resolveRoll(sum) {
    pushLog(`${currentPlayer.name} rolled ${sum}.`);
    if (sum === 7) {
      pushLog(`A 7! The robber stirs.`);
      setPhase('moveRobber');
      showToast('Move the robber');
      return;
    }
    // Distribute resources
    setHighlightedNumber(sum);
    setTimeout(()=> setHighlightedNumber(null), 1600);
    const gains = players.map(()=>({ wood:0, brick:0, wheat:0, sheep:0, ore:0 }));
    tiles.forEach((t, hid) => {
      if (t.number !== sum) return;
      if (hid === robberHex) return;
      // each settlement/city on its corners
      // find vertices at corners of this hex
      const corners = hexCorners(t.x, t.y);
      corners.forEach(([x,y]) => {
        const key = Math.round(x)+':'+Math.round(y);
        const s = settlements[key], c = cities[key];
        if (s) {
          const idx = players.findIndex(p=>p.id===s.playerId);
          if (idx>=0) gains[idx][t.resource] += 1;
        } else if (c) {
          const idx = players.findIndex(p=>p.id===c.playerId);
          if (idx>=0) gains[idx][t.resource] += 2;
        }
      });
    });
    setPlayers(prev => prev.map((p,i)=>({
      ...p,
      res: Object.fromEntries(Object.entries(p.res).map(([k,v])=>[k, v + gains[i][k]]))
    })));
    gains.forEach((g, i) => {
      const parts = Object.entries(g).filter(([,n])=>n>0).map(([r,n])=>`${n} ${r}`);
      if (parts.length) pushLog(`${players[i].name} gathered ${parts.join(', ')}.`);
    });
    setPhase('rolled');
  }

  // ---------- BUILD ----------
  function canAfford(kind, p) {
    if (kind==='road')       return p.res.wood>=1 && p.res.brick>=1 && p.roadsLeft>0;
    if (kind==='settlement') return p.res.wood>=1 && p.res.brick>=1 && p.res.wheat>=1 && p.res.sheep>=1 && p.settlementsLeft>0;
    if (kind==='city')       return p.res.wheat>=2 && p.res.ore>=3 && p.citiesLeft>0;
    if (kind==='dev')        return p.res.wheat>=1 && p.res.sheep>=1 && p.res.ore>=1;
    return false;
  }
  const DEV_CARDS = ['Knight','Road Building','Year of Plenty','Monopoly','Victory Point'];
  function onBuild(kind) {
    const p = players[currentPlayerIdx];
    if (!canAfford(kind, p)) return showToast('Not enough resources');
    if (kind==='road')       setPhase('buildRoad');
    if (kind==='settlement') setPhase('buildSettlement');
    if (kind==='city')       setPhase('buildCity');
    if (kind==='dev') {
      const d = DEV_CARDS[Math.floor(Math.random()*DEV_CARDS.length)];
      setPlayers(players.map((pl,i)=> i===currentPlayerIdx ? {
        ...pl, dev:(pl.dev||0)+1, devList:[...(pl.devList||[]), d],
        vp: pl.vp + (d==='Victory Point'?1:0),
        res: { ...pl.res, wheat:pl.res.wheat-1, sheep:pl.res.sheep-1, ore:pl.res.ore-1 }
      } : pl));
      pushLog(`${p.name} bought a development card.`);
      showToast(`Drew: ${d}`);
    }
  }

  // Rule 22: Play Knight — uses a Knight dev card, forces robber move.
  function onPlayKnight() {
    const p = players[currentPlayerIdx];
    const idx = (p.devList || []).indexOf('Knight');
    if (idx < 0) return showToast('No Knight in hand');
    if (phase !== 'rolled') return showToast('Play after rolling');
    setPlayers(players.map((pl,i)=> i===currentPlayerIdx ? {
      ...pl, dev: Math.max(0,(pl.dev||0)-1),
      devList: pl.devList.filter((_,j)=>j!==idx),
    } : pl));
    pushLog(`${p.name} played a Knight.`);
    setPhase('moveRobber');
    showToast('Move the robber');
  }

  function onBankTrade() {
    const { give, get } = tradeSel;
    if (!give || !get || give===get) return;
    const p = players[currentPlayerIdx];
    if (p.res[give] < 4) return showToast('Need 4 of that resource');
    setPlayers(players.map((pl,i)=> i===currentPlayerIdx ? {
      ...pl, res: { ...pl.res, [give]: pl.res[give]-4, [get]: pl.res[get]+1 }
    } : pl));
    pushLog(`${p.name} traded 4 ${give} for 1 ${get}.`);
    setTradeSel({ give:'', get:'' });
  }

  function endTurn() {
    // very simple AI: on its turn, it rolls then builds if possible
    const nextIdx = (currentPlayerIdx + 1) % players.length;
    setCurrentPlayerIdx(nextIdx);
    setPhase('idle');
    if (nextIdx === 0) setTurn(t => t+1);
    if (!players[nextIdx].isHuman) {
      setTimeout(() => aiTurn(nextIdx), merged.aiSpeed);
    }
  }

  function aiTurn(pIdx) {
    // Roll
    setRolling(true);
    setTimeout(() => {
      const a = 1+Math.floor(Math.random()*6), b = 1+Math.floor(Math.random()*6);
      setDice([a,b]);
      setRolling(false);
      const sum = a+b;
      pushLog(`${players[pIdx].name} rolled ${sum}.`);
      if (sum === 7) {
        // AI picks a non-desert, non-current hex
        const candidates = tiles.map((t,i)=>i).filter(i => i !== robberHex);
        const choice = candidates[Math.floor(Math.random()*candidates.length)];
        setRobberHex(choice);
        pushLog(`${players[pIdx].name} moved the robber.`);
      } else {
        setHighlightedNumber(sum);
        setTimeout(()=> setHighlightedNumber(null), 1500);
        const gains = players.map(()=>({ wood:0, brick:0, wheat:0, sheep:0, ore:0 }));
        tiles.forEach((t, hid) => {
          if (t.number !== sum || hid === robberHex) return;
          const corners = hexCorners(t.x, t.y);
          corners.forEach(([x,y]) => {
            const key = Math.round(x)+':'+Math.round(y);
            const s = settlements[key], c = cities[key];
            if (s) { const idx = players.findIndex(p=>p.id===s.playerId); if (idx>=0) gains[idx][t.resource] += 1; }
            else if (c) { const idx = players.findIndex(p=>p.id===c.playerId); if (idx>=0) gains[idx][t.resource] += 2; }
          });
        });
        setPlayers(prev => prev.map((p,i)=>({
          ...p,
          res: Object.fromEntries(Object.entries(p.res).map(([k,v])=>[k, v + gains[i][k]]))
        })));
        gains.forEach((g, i) => {
          const parts = Object.entries(g).filter(([,n])=>n>0).map(([r,n])=>`${n} ${r}`);
          if (parts.length) pushLog(`${players[i].name} gathered ${parts.join(', ')}.`);
        });
      }
      // Simple AI: end turn after a small delay
      setTimeout(() => {
        // try to "build" (just log, don't actually change board complexly)
        const nextIdx = (pIdx + 1) % players.length;
        setCurrentPlayerIdx(nextIdx);
        setPhase('idle');
        if (nextIdx === 0) setTurn(t => t+1);
        if (!players[nextIdx].isHuman) {
          setTimeout(() => aiTurn(nextIdx), merged.aiSpeed);
        }
      }, merged.aiSpeed);
    }, 700);
  }

  function newGame() {
    if (!confirm('Start a new game?')) return;
    localStorage.removeItem('katan.players');
    localStorage.removeItem('katan.settlements');
    localStorage.removeItem('katan.cities');
    localStorage.removeItem('katan.roads');
    localStorage.removeItem('katan.robber');
    localStorage.removeItem('katan.turn');
    localStorage.removeItem('katan.cp');
    localStorage.removeItem('katan.phase');
    localStorage.removeItem('katan.setupStep');
    localStorage.removeItem('katan.dice');
    localStorage.removeItem('katan.log');
    const ns = Math.floor(Math.random()*1000);
    localStorage.setItem('katan.seed', JSON.stringify(ns));
    window.location.reload();
  }

  // phase messages
  const phaseMsg = useMemo(() => {
    if (phase === 'placeSettlement1') return 'Click a highlighted vertex.';
    if (phase === 'placeRoad1') return 'Click an edge touching your settlement.';
    if (phase === 'placeSettlement2') return 'Click a highlighted vertex. You’ll collect from adjacent tiles.';
    if (phase === 'placeRoad2') return 'Click an edge touching your settlement.';
    if (phase === 'idle') return 'Tap Roll to gather resources.';
    if (phase === 'rolled') return 'Build, trade with the bank, or end your turn.';
    if (phase === 'buildSettlement') return 'Click a vertex adjacent to your road.';
    if (phase === 'buildCity') return 'Click one of your settlements to upgrade it.';
    if (phase === 'buildRoad') return 'Click an edge connected to your network.';
    if (phase === 'moveRobber') return 'Click any hex to move the robber there.';
    return '';
  }, [phase]);

  const boardState = {
    tiles, vertices: graph.vertices, edges: graph.edges,
    settlements, cities, roads, robberHex,
  };

  const canRoll  = phase === 'idle' && currentPlayer.isHuman;
  const canEnd   = phase === 'rolled' && currentPlayer.isHuman;
  const canBuild = phase === 'rolled' && currentPlayer.isHuman;

  return (
    <>
      <div className="table-bg"/>
      <div className="vignette"/>
      <div className="app">
        <div className="board-stage">
          {toast && <div className="toast">{toast}</div>}
          <div className="board-wrap">
            <Board state={boardState}
              onVertexClick={handleVertexClick}
              onEdgeClick={handleEdgeClick}
              onHexClick={handleHexClick}
              highlightedNumber={highlightedNumber}
              phase={phase}
              currentPlayer={currentPlayer}
              turn={turn}
              showPips={merged.showPips}/>
          </div>
        </div>
        <Panel
          players={players}
          currentPlayerIdx={currentPlayerIdx}
          phase={phase}
          phaseMsg={phaseMsg}
          log={log}
          dice={dice}
          rolling={rolling}
          onRoll={rollDice}
          onEndTurn={endTurn}
          onBuild={onBuild}
          onTrade={onBankTrade}
          onUndo={newGame}
          canRoll={canRoll}
          canEnd={canEnd}
          canBuild={canBuild}
          turn={turn}
          tradeSel={tradeSel}
          setTradeSel={setTradeSel}
          onBankTrade={onBankTrade}
          onPlayKnight={onPlayKnight}
        />
      </div>

      {/* Rule 21: victim-selection dialog */}
      {victimChoice && (
        <div className="victim-modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="victim-title">
          <div className="victim-modal">
            <h3 id="victim-title">Steal from…</h3>
            <p className="victim-sub">The robber is adjacent to multiple opponents. Pick one to steal from.</p>
            <div className="victim-choices">
              {victimChoice.map(pid => {
                const vp = players.find(p => p.id === pid);
                const hand = Object.values(vp.res).reduce((a,b)=>a+b,0);
                return (
                  <button key={pid} className="victim-btn" onClick={()=>stealFrom(pid)}>
                    <span className="player-swatch" style={{background: vp.rawColor}}/>
                    <span>{vp.name}</span>
                    <span className="victim-hand">{hand} cards</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {editMode && (
        <div className="tweaks">
          <h4>Tweaks</h4>
          <div className="tweak-row">
            <label>AI speed (ms)</label>
            <input type="range" min="200" max="2000" step="100"
              value={merged.aiSpeed}
              onChange={e=>updateTweak('aiSpeed', +e.target.value)}/>
          </div>
          <div className="tweak-row">
            <label>Show pips</label>
            <input type="checkbox" checked={!!merged.showPips}
              onChange={e=>updateTweak('showPips', e.target.checked)}/>
          </div>
          <div className="tweak-row">
            <label>Board seed</label>
            <button onClick={()=>{ const s = Math.floor(Math.random()*1000); setSeed(s); }}>Randomize</button>
          </div>
          <div className="tweak-row">
            <label>Reset game</label>
            <button onClick={newGame}>New game</button>
          </div>
        </div>
      )}
    </>
  );
}

Object.assign(window, { App });

// Mount
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
