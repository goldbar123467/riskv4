# Katan — UI Audit

**Scope:** visual + structural issues observable in `Katan.html` at the state shown (Round 1, `phase = placeSettlement1`, 4 players, pre-placement).
**Legend:** `P0` = broken / load-bearing bug · `P1` = visually wrong or misleads the player · `P2` = polish / design-system drift.

---

## TL;DR

The board has three structural rendering bugs (ocean hex undersized and mis-transformed; 8 of 9 harbors land on interior edges; robber/chit/vertex-spot layering is noisy) and the panel quietly contradicts its own design system by shipping emoji where SVG glyphs were promised. The setup-phase UX also over-promises: every one of the 54 vertices pulses simultaneously, which is visually chaotic *and* wrong — legal first-placements are gated by the distance rule, not "any corner." Fix list is below in severity order.

---

## P0 — Broken rendering / load-bearing bugs

### P0-1 · The ocean ring doesn't enclose the island
**File:** `board.jsx:373–388`

Ocean hex radius is `HEX_SIZE * 3.75 = 292.5`. The farthest *vertex* on the 19-tile island sits at roughly `HEX_SIZE * sqrt(3) * 2 + HEX_SIZE = 348` horizontally and `HEX_SIZE * 1.5 * 2 + HEX_SIZE = 312` vertically. The island pokes out of the ocean — coastal hexes render directly on the dark-wood table. That's why you see no water: the water is *inside* the tiles, not around them.

Then `transform="scale(.955) translate(23 23)" style={{transformOrigin:'500px 510px'}}` makes it worse. SVG transform attributes apply right-to-left and **ignore** CSS `transform-origin` on the attribute form in most browsers. The intended "inset ocean" shrinks around the wrong origin.

**Fix:**
```ts
const OCEAN_R = HEX_SIZE * 4.6; // leave a real margin
const innerScale = 0.96;
// Pre-compute the inner path instead of CSS-transforming it:
const innerPts = pts.map(([x, y]) => [
  BOARD_CX + (x - BOARD_CX) * innerScale,
  BOARD_CY + (y - BOARD_CY) * innerScale,
]);
```
Stop relying on mixed attribute/style transforms. Either go all-attribute (`transform="matrix(...)"`) or apply `transform` via CSS and drop the attribute. **Tradeoff:** a larger ocean means the board-wrap viewBox needs to grow (see P2-1), which shrinks the hexes slightly at the current panel width.

### P0-2 · 8 of 9 harbors land on non-coastal edges
**File:** `board.jsx:107–119`

`HARBORS` lists `{tileIdx, side, kind}` but the `side` values don't correspond to coastal edges. Walking the axial neighbor map for pointy-top (`E, SE, SW, W, NW, NE` ↔ sides `0..5`):

| tileIdx | axial   | coastal sides | configured side | result |
|---------|---------|---------------|-----------------|--------|
| 0       | (0,-2)  | 3, 4, 5       | 0 (right)       | ❌ inside |
| 2       | (2,-2)  | 0, 4, 5       | 1 (SE)          | ❌ inside |
| 6       | (2,-1)  | 0, 5          | 1 (SE)          | ❌ inside |
| 11      | (2,0)   | 0, 1          | 2 (SW)          | ❌ inside |
| 18      | (0,2)   | 0, 1, 2       | 2 (SW)          | ✅ coast |
| 17      | (-1,2)  | 1, 2          | 3 (W)           | ❌ inside |
| 16      | (-2,2)  | 1, 2, 3       | 4 (NW)          | ❌ inside |
| 12      | (-2,1)  | 2, 3          | 4 (NW)          | ❌ inside |
| 7       | (-2,0)  | 3, 4          | 5 (NE)          | ❌ inside |

Exactly the symptom: one small dock visible near tile 18 bottom-right; everywhere else the pier lines are buried between adjacent land hexes and invisible.

**Fix:** derive coastal edges from the graph, don't hard-code:
```ts
type Side = 0 | 1 | 2 | 3 | 4 | 5;
const OFFSETS: Record<Side, [number, number]> = {
  0: [1, 0],  1: [0, 1],  2: [-1, 1],
  3: [-1, 0], 4: [0, -1], 5: [1, -1],
};
const isCoastal = (t: Tile, side: Side, byAxial: Map<string, Tile>) => {
  const [dq, dr] = OFFSETS[side];
  return !byAxial.has(`${t.q + dq},${t.r + dr}`);
};
```
Then assign harbor `side` programmatically from the first coastal side (or enforce standard Catan harbor positions, which are fixed across editions — see Catan base rulebook §Setup).

**Tradeoff:** deriving harbors drops the hand-placed look; if you want the classic base-game harbor distribution exactly, hard-code by coastal-edge index (0..17 around the perimeter), not by tile+side.

### P0-3 · `(60*side - 30 + 30)` is a tell
**File:** `board.jsx:309`

The expression `angDeg = 60*side - 30 + 30` simplifies to `60*side`. That's mathematically fine for edge midpoint, but the dead arithmetic suggests this was ported without understanding which constant was which. Left as-is, it's a comment-level bug; pair with the P0-2 fix and simplify to `60 * side` with a one-line comment: `// midpoint angle of side i for pointy-top hex`.

### P0-4 · Setup phase highlights illegal vertices
**File:** `board.jsx:450–459`, game logic in `game.jsx`

The base-game distance rule: no settlement may be placed on a vertex adjacent (by one edge) to an existing settlement or city. At round 1, placement 1 this is moot, but placement 2 and every post-setup placement must filter. The current code paints all 54 vertex spots as legal:
```jsx
{showVertexSpots && Object.values(vertices).map(v => (...))}
```

**Fix:** derive legality from graph, typed:
```ts
type VertexId = string & { readonly __brand: 'VertexId' };
const legalSettlementVertices = (
  v: Record<VertexId, Vertex>,
  edgeByVertex: Record<VertexId, VertexId[]>,
  occupied: Set<VertexId>,
): Set<VertexId> => {
  const blocked = new Set<VertexId>();
  for (const oid of occupied) {
    blocked.add(oid);
    for (const n of edgeByVertex[oid]) blocked.add(n);
  }
  return new Set((Object.keys(v) as VertexId[]).filter(id => !blocked.has(id)));
};
```
Then `showVertexSpots && legal.has(v.id)`. **Tradeoff:** players briefly lose the "preview everything" affordance. Net positive — the board currently looks like a circuit board.

### P0-5 · 108 concurrent SMIL animations on setup
**File:** `board.jsx:453–458`

Every vertex spot renders two `<animate>` elements. 54 vertices × 2 animations = 108 simultaneous SMIL timers, and the outer-ring `r` animation overrides the static `r="17"`. On classroom Chromebooks (which is the real deployment surface given where this conversation sits), this jitters.

**Fix:** one CSS animation, not per-element SMIL:
```css
.vertex-spot-ring { animation: v-pulse 1.6s ease-in-out infinite; transform-origin: center; transform-box: fill-box; }
@keyframes v-pulse { 0%,100% { r: 13; opacity: .7 } 50% { r: 20; opacity: .2 } }
```
(Or scale via `transform` and avoid animating `r` entirely — SMIL on `r` forces SVG reflow.) Only render spots for *legal* vertices (see P0-4), cutting the count ~3×. **Tradeoff:** animating CSS `r` has uneven browser support pre-Chrome 118; if your Chromebook fleet lags, animate a scale transform on a wrapper `<g>` instead.

---

## P1 — Visually wrong / misleads the player

### P1-1 · Number chits are offset downward inside the hex
**File:** `board.jsx:417` → `cy={t.y + 28}`

Chit center sits 28px below hex center; emblem sits at `y - 6`. That makes every hex top-weighted with a chit hanging off the lower half. The classic Catan layout centers the chit and omits the emblem (or uses a faint watermark). Current placement also makes the chit visually collide with vertex spots on the *next row down*, confusing hit-targets.

**Fix:** center chit at `cy = t.y`, move emblem to `cy = t.y - 30` at reduced opacity, or drop the emblem (color already encodes resource).

### P1-2 · Pip dots are unreadable
**File:** `board.jsx:248` → `r="1.6"`

Pip count *is* the strategic signal — 6 and 8 at five dots each should **read as five dots** from across a desk. At r=1.6 and 6px spacing on a 22px chit, they blur into a smear. The whole OWC-vs-Wood-Brick read of the board is: scan for dot clusters. Right now you can't.

**Fix:** `r="2.4"`, spacing `7.5px`, chit radius `26`. For red numbers (6/8) use a slightly thicker pip: `r="2.6"` and stroke. **Tradeoff:** larger pips fight the number glyph for space; compensate by dropping the chit's inner cream circle (`r=22`) and widening the outer ring.

### P1-3 · Red numbers don't read as red enough
**File:** `board.jsx:242–248`

`#b91c1c` is correct-ish (Catan official red is closer to `#c41e3a`), but on the cream chit at 25px Cormorant the red reads as "dark brown" until you're three feet from the screen. Boost saturation or add a thin red outline to the 6/8 chits themselves (stroke `#b91c1c` at 2px).

### P1-4 · The robber renders half off the desert
**File:** `board.jsx:294–304`

`scale(1.6)` on a design that was built at scale 1 means the base ellipse (the shadow at `cy="14"`) lands at `y + 22` relative to tile center. With chit at `y + 28` (on non-desert) and hex extending to `y + 78`, you get away with it — but the desert has no chit to occlude, so the robber sits low on the hex, visually "falling into the ocean" (see crop). Pull it up: drop the inner `translate(0 -14)` and use `scale(1.4)` with `translate(0 -22)`.

### P1-5 · The panel ships emoji despite a comment saying not to
**File:** `panel.jsx:9–10, 115, 116, 141–144`

Line 10 literally reads:
```js
// but design system says avoid emoji; use SVG glyphs instead
```
…immediately after defining an emoji map. Then `player-row` renders `✋ {count}` and `◆ {count}`, and the action row shows `🌲🧱🌾🐑` as recipe icons. Emoji render inconsistently across OSes (Windows's segoe-emoji vs. Apple's vs. the Chromebook fleet's Noto Color Emoji), break at small sizes, and are an a11y tax for screen readers. Since you already have the `Glyph` SVG in `ResourceCard`, extract it into a shared `<ResIcon kind={r} size={12}/>` and use it everywhere.

### P1-6 · Setup-phase dice tray is loud and disabled
**File:** `panel.jsx:94–106`, `styles.css:338`

During `placeSettlement1` the dice show `• • 2 DOUBLES` with a full orange ROLL button that's disabled. That's three problems stacked:
1. "DOUBLES" is a Monopoly concept, not a Catan mechanic — label should just say `SUM` (or nothing).
2. Showing a dice result before any roll is confusing — pre-roll state should render blank faces or hide entirely.
3. Orange-primary `ROLL` during setup collides with P1's (your) player color, visually implying the button is the active-player identity.

**Fix:** gate the dice tray behind `phase !== 'placeSettlement1' && phase !== 'placeRoad1' && ...`; render a placeholder "Setup" badge instead. Or render the tray but with empty dice faces and the ROLL button using a neutral-ghost style until `phase === 'idle'`.

### P1-7 · Vertex spots collide with top-row number chits
**File:** `board.jsx:417, 453`

Top-row chits (`cy = t.y + 28`) sit where the *south vertices* of that row live. Those vertices get orange `r=13` spots drawn on top of the chit number. Screenshot shows it clearly on the top "9" chit. Moving the chit to `cy = t.y` (P1-1) fixes half of this; adding `pointer-events: none` on the chit group is the other half so it doesn't steal clicks from the vertex spot.

### P1-8 · VP target is never surfaced
**File:** `panel.jsx` — missing

Nothing in the panel tells a new player they're racing to 10. The phase title says "Place your first settlement"; the turn card shows `VP 0`. A small `0 / 10 VP` progress pill or a `TO WIN · 10` micro-label near the turn card would frame the whole game. Consider adding it under `.brand-sub`:
```tsx
<div className="brand-sub">Settlers of the Hex Isle · round {turn} · first to 10</div>
```

### P1-9 · Desert emblem is invisible
**File:** `board.jsx:181–187`

Opacity 0.55 on a two-stroke wave + tiny circle, on a `#d9bb7a` base — you can't tell the desert from the unrevealed no-number tile. A minimal desert needs *one* clear mark. Try a 14px sun with three short rays at opacity 0.7, or accept that the desert is "the tile with no chit" and remove the emblem entirely.

### P1-10 · Player-color / hex-color / brand collisions
**File:** `styles.css:47–50`

- `--p1: #e07b1c` (orange) ≈ `.btn.primary` gradient ≈ brick-hi `#d46a3e`.
- `--p4: #2e7d4a` (forest green) ≈ `--forest: #2d5a2d` (wood hex base).
- Jules's roads on wood hexes will be genuinely hard to spot.

**Fix:** push P4 toward a darker, bluer green (`#1f6b3c`) or a teal. **Tradeoff:** deviates from the traditional red/blue/orange/white four-color Catan palette — but the board's color palette is richer than classic Catan's felt board, which *needs* more contrast in the piece colors.

---

## P2 — Polish

### P2-1 · ViewBox aspect is 920×900, container is 1/1
**File:** `board.jsx:346`, `styles.css:112`

`viewBox="40 60 920 900"` with `aspect-ratio: 1/1` on `.board-wrap` + `preserveAspectRatio="xMidYMid meet"` letterboxes ~16px vertically. Either pick a square viewBox (e.g., compute `max(width, height)` around the ocean) or change container `aspect-ratio` to `920/900`.

### P2-2 · Stat-pill hierarchy is inconsistent
**File:** `styles.css:244–255`, `panel.jsx:114–116`

`.stat-pill.vp` is filled cream; the hand/dev pills are transparent-bordered. Three pills in a row with one visually heavier makes "VP" look like a button. Pick one treatment; my vote is: all pills ghost, then color the **number** in the VP pill by player color. That keeps visual weight consistent but surfaces the thing that matters.

### P2-3 · `icons` emoji map is dead code
**File:** `panel.jsx:9`

Defined, never used after the `Glyph` override on line 11. Delete it.

### P2-4 · `RESOURCE_LABEL` exposed on `window` but never rendered
**File:** `board.jsx:130, 472`

If the plan is to show `FOREST / PASTURE / FIELD / HILLS / MOUNTAIN` somewhere (tooltip on hex hover? hand-card label?), wire it up. Otherwise drop the constant and the `window` assign. Right now the hand labels read `wood / brick / wheat / sheep / ore` (panel) while the hex internal name uses the other set — not visible, but it's an invariant waiting to bite the next person who touches this.

### P2-5 · `player-row` grid squeezes with longer names
**File:** `styles.css:229`

`grid-template-columns: 14px 1fr auto auto auto` is fine at "Albrecht" length. At "Concept Schools SS Director" length (or if you ever do AI-name lists for students), the three pills crowd. Set `min-width: 0` on the name cell and `white-space: nowrap; text-overflow: ellipsis;` for safety.

### P2-6 · `phase-hint` contrast
**File:** `styles.css:214` — `color: var(--parch-ink-soft)` on `--parch-100` background

`#5b4a32` on `#ead7a8` = ~4.35:1. Just under WCAG AA 4.5:1 for body text. Bump to `#4a3c29` or use `var(--parch-ink)` at 0.72 alpha.

### P2-7 · Scrollbar thumb only styled for webkit
**File:** `styles.css:168, 313`

`::-webkit-scrollbar` only. Firefox + Chromebook touch devices often render default. Add `scrollbar-width: thin; scrollbar-color: var(--parch-rule) transparent;` on `.panel-inner` and `.log`.

### P2-8 · Log is fixed 120px tall below the fold at 720p
**File:** `styles.css:306`

At 1366×720 (the laptop/Chromebook standard), with the current panel content stack, the game log scrolls off-screen. For a 5th/6th-grade classroom context the log is where you *explain what just happened* — it should be visible, not buried. Reflow: collapse `Actions` + `Bank trade` behind an expando during setup phase; surface `Log` earlier. Phase-aware panel layout is worth the reducer complexity.

### P2-9 · Board is 400×400 of dead wood on the left
**File:** `styles.css:93–104`

`.app { grid-template-columns: 1fr 400px }` plus `.board-wrap { width: min(98vh, calc(100vw - 420px)) }` centers the board inside `1fr`, meaning at 1366px viewport the board is ~706px wide in a ~946px column — 240px of ambient dark wood on each side. At classroom projector resolutions (1920×1080 common) it's worse. Options:
- `grid-template-columns: minmax(0, 1fr) 400px` and `.board-wrap { width: 100%; max-width: min(95vh, 100%); }` to let the board fill.
- Keep the margin as "table felt" and add something useful in it: a large highlighted-number readout during `rolled` phase, or a mini-map of which players are near victory.

### P2-10 · `Board` component takes 7 flat props
**File:** `board.jsx:334`

`state, onVertexClick, onEdgeClick, onHexClick, highlightedNumber, phase, currentPlayer` — workable, but the next feature (trade UI? dev card reveal? robber-steal-picker?) adds an 8th prop. Move to a compound pattern:
```tsx
<BoardProvider value={{ state, phase, currentPlayer, callbacks }}>
  <Board.Root>
    <Board.Ocean />
    <Board.Harbors />
    <Board.Hexes onClick={...} />
    <Board.Pieces />
    <Board.PlacementSpots />
    <Board.Robber />
  </Board.Root>
</BoardProvider>
```
**Tradeoff:** Context re-renders all children on state change unless you split contexts (one for static geometry, one for callbacks, one for dynamic state). Worth it at this component's size; premature for a 50-line board.

### P2-11 · `.btn.primary` gradient uses raw hex, not tokens
**File:** `styles.css:328`

`#d96b1c, #a84c0f` are close to but not exactly `--p1` (`#e07b1c`). If you ever re-theme, you'll miss this. Use `color-mix(in oklch, var(--p1) 100%, black 10%)` for the gradient low stop.

### P2-12 · SMIL `<animate>` on chit "highlighted"
**File:** `board.jsx:252–255`

Same pattern as vertex spots. Single highlighted chit is fine; the bigger point is consistency — move all animation to CSS, keep SVG static. Respect `prefers-reduced-motion` (currently nothing does).

### P2-13 · Dev card area uses flat pills with no type distinction
**File:** `panel.jsx:131–135`

Every dev card renders as the same cream chip. Knight vs. Road Building vs. Year of Plenty vs. VP card have **different strategic stories** (Knight threatens robber moves; VP cards hide in hand until the 7→10 surprise). Color-code at minimum; icon them if possible.

### P2-14 · "DOUBLES" label on the dice sum
**File:** `panel.jsx:100`

Already called out in P1-6 but worth repeating: doubles are a Monopoly artifact, not Catan. Catan cares about the sum. Replace with `SUM` or `d = N` mono.

### P2-15 · Board SVG has no `role` or `aria-label`
**File:** `board.jsx:346`

`<svg role="img" aria-label={`Catan board, round ${turn}, ${phase}`}>` at minimum. Vertex spots are `<g>` with click handlers and no labels → unusable by keyboard or screen reader. Per the stated design system ("Make every hex/vertex/edge a focusable button"), this needs to be `<g role="button" tabIndex={0} aria-label={vertexLabel(v)} onKeyDown={...}>`.

---

## Design-system drift summary

1. **Emoji promised gone, shipped anyway** (P1-5).
2. **SMIL animations in a "compound components + CSS vars" stack** (P0-5, P2-12).
3. **Color tokens exist but gradients use raw hex** (P2-11).
4. **`any`-free TS claimed but geometry + graph have no branded types** visible in the current `.jsx` scaffold — the port to `ts/` is the moment to introduce `VertexId`, `EdgeId`, `TileId`, `HexAxial = { q: number; r: number }`.
5. **No `prefers-reduced-motion` guard anywhere** — classroom deployment makes this non-optional.

---

## Suggested fix order

1. P0-2 harbors (biggest perceived fix, ~15 min).
2. P0-1 ocean frame (unlocks visual identity).
3. P1-1 / P1-2 / P1-7 chit layout + pip size (makes the board *playable*, not just pretty).
4. P1-5 emoji extermination + `<ResIcon/>` component.
5. P0-4 legal-vertex filter + P0-5 SMIL→CSS (same PR).
6. P1-6 setup dice gating.
7. P2-15 a11y pass.
8. Everything else as paint-over.

Total: ~1 focused afternoon to get this from "demo" to "classroom-ready" for the 5th/6th-grade context.
