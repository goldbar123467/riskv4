# Katan — UI Audit v2

**Scope:** visual + structural pass on the updated `Katan.html` prototype and `ts/` port at the state shown (Round 1, `phase = placeSettlement1`, 4 players, pre-placement, seed from localStorage).
**Legend:** `P0` = broken / load-bearing · `P1` = wrong or misleads · `P2` = polish.

---

## TL;DR

The v1 fix pass landed cleanly: ocean visible, 9 harbors on actual coast, pips legible, red chits outlined, legal-vertex filter wired, emoji gone, SMIL → CSS with a `prefers-reduced-motion` guard, `color-mix` on the primary gradient, P4 moved to teal, "first to 10" surfaced. Every P0 and P1 from v1 is addressed in `.jsx`.

What v2 finds: **one visible correctness regression** (robber on a brick hex, not the desert — stale-localStorage class bug that threatens all layout-dependent persisted state), **two a11y regressions** introduced by the cleanup (54 tab stops, `role="img"` occlusion), **one phase-unaware hand treatment** that looks dead at setup, and **the entire `ts/` port is ~one commit behind** `.jsx` — every v1 P0 is back in TypeScript land. The live HTML is in better shape than v1. The TS project is strictly worse than the JSX it's supposed to mirror.

---

## v1 fixes verified ✅

All P0 and P1 from v1 confirmed in the live `.jsx`. I'll spare the re-enumeration — they're in `board.jsx:489–503` (ocean), `:122–149` (harbors), `:269–298` (chits), `:332–342` (robber render), `:370–411` (legal filters), `panel.jsx:5–17` (ResIcon), `:108–120` (setup dice), `styles.css:128–142` (CSS animations + reduced-motion). No regressions on the v1 items themselves.

---

## P0 — Load-bearing bugs (v2)

### P0-1 · Robber renders on a brick hex, not the desert
**File:** `game.jsx:43`, visible in screenshot

```js
const [robberHex, setRobberHex] = useLS('katan.robber', tiles.findIndex(t=>t.resource==='desert'));
```

`useLS` only uses the default when `localStorage['katan.robber']` is empty. The screenshot shows the robber sitting on a red brick tile with the desert (tan, sun emblem, no chit) untouched at the bottom-right. That means localStorage has a stored `robberHex` index from an earlier session whose layout was different — code rev, seed change, or shuffle change between versions — and the index now points to a tile that used to be desert but isn't any more.

**Fix:** validate on load, not just at first-write.
```ts
const desertIdx = tiles.findIndex(t => t.resource === 'desert');
const [robberHex, setRobberHex] = useLS('katan.robber', desertIdx);
useEffect(() => {
  if (tiles[robberHex]?.resource !== 'desert' && Object.keys(settlements).length === 0) {
    setRobberHex(desertIdx);
  }
}, [desertIdx]); // only fires when the layout changes
```
The "no settlements yet" guard stops a mid-game reset from teleporting the robber off a legitimate mid-game position.

### P0-2 · `settlements`, `cities`, `roads` share the same stale-key hazard
**File:** `game.jsx:40–43`

Same pattern. vKey and eKey are rounded pixel coordinates, which are stable across seeds because `HEX_SIZE`/`BOARD_CX`/`BOARD_CY` are constants. So if a previous session placed a settlement at vKey `"312:454"` and that vertex was adjacent to a sheep hex, a new session with a reshuffled layout will silently re-mount that settlement at `"312:454"` — now adjacent to, say, ore. Not visible in the screenshot (no placements yet) but the class of bug is live.

**Fix:** namespace layout-dependent state by a layout version:
```ts
const layoutKey = `katan.layout-${seed}-v1`;
const [settlements, setSettlements] = useLS(`${layoutKey}.settlements`, {});
// ...same for cities, roads, robberHex
```
Bumping `-v1 → -v2` is then a one-line invalidation when you change the shuffle or hex math. `newGame()` at `:472` already removes the raw keys, but that doesn't help on natural seed drift between code versions — the LS version bump is the right primitive. **Tradeoff:** LS keys grow; write a janitor that clears keys not matching the current layoutKey on mount.

### P0-3 · `ts/` port is a full revision behind `.jsx`
**Files:** `ts/src/boardGeometry.ts:103–113`, `ts/src/Board.tsx:240–241, 259, 268–292`

Every v1 P0 I called out is back in the TypeScript source:

| v1 item | `.jsx` | `ts/` |
|---|---|---|
| P0-1 Ocean radius + transform-origin | fixed (4.6× + pre-computed inner) | **broken** — `ts/src/Board.tsx:240–241` still has `transform="scale(.955) translate(23 23)"` + `style={{transformOrigin:'500px 510px'}}` |
| P0-2 Harbor positions | fixed (`computeHarbors` derives from coast) | **broken** — `ts/src/boardGeometry.ts:103–113` exports the same hand-placed non-coastal `HARBORS` array from v1 |
| P0-4 Legal-vertex filter | fixed (`legalSettlementVertices`) | **missing** — `ts/src/Board.tsx:284` still renders `Object.values(vertices).map(...)` unfiltered |
| P0-5 SMIL → CSS | fixed | **back to SMIL** — `ts/src/Board.tsx:254, 288–289` has `<animate>` tags |
| P1-1 Chit centered | fixed (`cy = t.y`) | **offset** — `ts/src/Board.tsx:259` still `cy={t.y + 28}` |
| P1-2 Pip size / P1-3 red stroke | fixed | likely still broken — inherits v1 chit rendering |
| P2-15 A11y roles | fixed | **missing** — no role/tabIndex/aria on vertex/edge/robber spots |

If `ts/` is the future and the JSX is the sketch pad, this is a one-commit port from the current `.jsx` to catch `ts/` up. If `ts/` is dead, delete it — right now it reads like an actively-developed alternative and anyone forking the repo will trip over the broken version.

**Fix path:** port `board.jsx`'s v2 state to `ts/src/Board.tsx` and `boardGeometry.ts`, introducing branded types along the way:
```ts
export type VertexId = string & { readonly __brand: 'VertexId' };
export type EdgeId   = string & { readonly __brand: 'EdgeId' };
export type TileId   = number & { readonly __brand: 'TileId' };
export type Side     = 0 | 1 | 2 | 3 | 4 | 5;

export const vertexKey = (x: number, y: number): VertexId =>
  (Math.round(x) + ':' + Math.round(y)) as VertexId;
```
Your `Record<string, Vertex>` maps become `Record<VertexId, Vertex>` and "did I mix an edge key with a vertex key" becomes a compile error instead of a runtime bug.

---

## P1 — Wrong or misleads (v2)

### P1-1 · 54 tab stops cover the board during setup
**File:** `board.jsx:580–593`

Every vertex spot renders `role="button" tabIndex={0}`, so the Tab key hits 54 focus stops on the board before reaching the panel. The spec you pasted is explicit about the target: *"Make every hex/vertex/edge a focusable button with descriptive labels. Keyboard navigation between adjacent hexes via arrow keys using cube-coordinate neighbors."* This is the arrow-key part that's missing.

**Fix:** roving tabindex. One vertex has `tabIndex={0}`, the rest have `tabIndex={-1}`, arrow keys move focus to the cube-coordinate neighbor:
```ts
// vertex graph already has neighbors via edges; derive cube-adjacent vertices once
function vertexCubeNeighbors(vertices: Record<VertexId, Vertex>, edges: Record<EdgeId, Edge>) {
  const map: Record<VertexId, VertexId[]> = {};
  for (const e of Object.values(edges)) {
    (map[e.a] ??= []).push(e.b);
    (map[e.b] ??= []).push(e.a);
  }
  return map;
}
// in Board:
const [focusVertex, setFocusVertex] = useState<VertexId | null>(null);
const onKey = (vKey: VertexId, e: KeyboardEvent) => {
  const nbrs = cubeNeighbors[vKey];
  // map arrow directions to nearest-angle neighbor using dx/dy of each candidate
  // then setFocusVertex(best) and .focus() it via ref map
};
```
**Tradeoff:** more code; but the current state is functionally keyboard-hostile for anyone not using a mouse, which is disqualifying for a classroom deployment.

### P1-2 · `role="img"` on the root SVG hides interactive children from AT
**File:** `board.jsx:462`

```tsx
<svg role="img" aria-label={`Katan board — round ${turn || 1}, ${phase}`}>
```

`role="img"` is a leaf role in ARIA — AT typically announces the `aria-label` and then stops traversing children. The settlement/robber/edge buttons underneath become unreachable. The fix depends on intent:

- **Screen-reader-reachable board:** drop `role` entirely (SVG exposes its interactive descendants) and put `aria-label` on a `<g role="group">` wrapper that holds the hexes; put a `<title>` as the first child of `<svg>` for the summary description.
- **Opaque-image-with-description:** keep `role="img"` and provide a parallel hidden DOM of buttons outside the SVG that mirror the actions, synced via `aria-activedescendant`. Overkill here.

**Recommended:**
```tsx
<svg aria-labelledby={titleId} aria-describedby={phaseId}>
  <title id={titleId}>Katan board</title>
  <desc id={phaseId}>Round {turn}, {phaseMsg}</desc>
  <g role="group" aria-label="Board hexes">...tiles</g>
  <g role="group" aria-label="Placement spots">...vertex-spots</g>
</svg>
```

### P1-3 · Zero-hand at setup reads as "dead UI"
**File:** `styles.css:308`, `panel.jsx:144–147`

`.rcard.zero { opacity: .45; filter: saturate(.5); }` is the correct "you have none of this" treatment during a real game turn (the player is meant to notice they're out of brick). At setup, though, **everyone has zero of everything**, by definition, so the entire hand renders as a row of washed-out pastel tiles. Screenshot confirms — the hand section visually flatlines.

**Fix:** phase-aware treatment. Options:
- Hide the hand entirely during `placeSettlement1`/`placeRoad1` and the first half of setup.
- Render a neutral "slot" during setup — parchment tile with just the `<ResIcon/>` glyph at 60% opacity, no gradient, count hidden.
```tsx
<div className={cx('rcard', kind, { zero: n === 0 && !isSetup, slot: isSetup })}>
```
```css
.rcard.slot {
  background: rgba(255,245,220,.35);
  color: var(--parch-ink-soft);
  box-shadow: inset 0 0 0 1px var(--parch-rule);
}
.rcard.slot .rn, .rcard.slot .rl { opacity: 0; }
```
**Tradeoff:** hiding the hand until after setup is simpler and conveys more — the hand *literally doesn't exist* until the second settlement grants starting resources, so showing it at all before `placeSettlement2` arguably over-promises.

### P1-4 · VP progress typography is marginal
**File:** `panel.jsx:99–102`, `styles.css:217–219` (turn-meta)

`0 / 10 VP` is THE game-state metric — you're racing to 10. It renders in 11px IBM Plex Mono, right-aligned, visually subordinate to "You" in 22px Cormorant. Screenshot crop confirms: the eye goes to the player name, then the orange swatch, and the VP progress is basically parsley.

**Fix:**
```tsx
<div className="turn-meta">
  <div className="turn-vp"><span className="big">{p.vp}</span><span className="small">/ 10 VP</span></div>
  <div className="turn-hand">HAND {handCount}</div>
</div>
```
```css
.turn-vp .big   { font-family: 'Cormorant Garamond', serif; font-size: 24px; font-weight: 600; color: var(--parch-ink); margin-right: 4px; }
.turn-vp .small { font-family: 'IBM Plex Mono', monospace; font-size: 10px; color: var(--parch-ink-soft); letter-spacing: .15em; }
.turn-hand      { font-family: 'IBM Plex Mono', monospace; font-size: 10px; color: var(--parch-ink-soft); margin-top: 2px; }
```
**Tradeoff:** adds a display pairing style that didn't exist before; keep it to this one card.

### P1-5 · `pendingAnchor` can select the wrong anchor settlement mid-setup
**File:** `board.jsx:445–454`

```ts
const candidates = Object.entries(settlements)
  .filter(([, o]) => o.playerId === pId)
  .map(([vKey]) => vKey)
  .filter(vKey => !(vertexNeighbors[vKey] || []).some(n => roads[n.eKey]?.playerId === pId));
return candidates[candidates.length - 1] || null;
```

`Object.entries(settlements)` iteration order is insertion order for string keys, which works — *if* keys are inserted in placement order. But `vKey` is a coordinate string like `"312:454"` and nothing enforces insertion order on the JSON-serialized LS blob. After `useLS` reads from localStorage, iteration order is whatever `JSON.parse` produced, which on V8 is... still insertion order for string keys, but you're one step away from a subtle bug if anyone ever normalizes the keys (e.g., sorts them for debugging).

**Fix:** store placement order explicitly:
```ts
type Settlement = { playerId: PlayerId; color: string; placedAt: number };
// and pick the candidate with the highest placedAt for the current player
```
**Tradeoff:** one more field in persisted state; LS version bump required (see P0-2).

---

## P2 — Polish (v2)

### P2-1 · `HexTile` re-renders on every state change
**File:** `board.jsx:230–266`

19 hex tiles, each with 6 randomized wood-grain paths + `ResourceEmblem` + gradient + clipPath. On any state update (dice roll, settlement placed, even phase transition) React re-renders all 19. Geometry and resource are stable for the lifetime of the board.

**Fix:** `React.memo(HexTile, (a, b) => a.tile.id === b.tile.id && a.dim === b.dim)`. Same for `NumberChit`, `Harbor`, `Road`, `Settlement`.

### P2-2 · Harbor labels still small (10px)
**File:** `board.jsx:362–364`

Kept at `fontSize={kind==='3:1'?9:10}` with a 12px-radius inner chip. At projector distance on a 1080p Chromebook deployment the ratio disappears.

**Fix:** inner chip `r=14`, outer `r=17`, font-size 11 for `2:1`, 10 for `3:1`. The `3:1` label has one more character so one size smaller is fine.

### P2-3 · Number-chit text offset is asymmetric
**File:** `board.jsx:278` — `y={cy - (showPips ? 3 : 1)}`

When pips are visible, the number shifts up 3px to make room for pips below. Combined with `dominantBaseline="middle"`, the number ends up visually above chit center by ~3px — screenshot shows this when you look at chits 2 and 3 (their pip count is 1–2, so visually tiny) against 6 and 8 (5 pips, bigger optical mass below): the 2 and 3 chits look top-heavy.

**Fix:** offset pips instead of the number. Keep number at `cy` with `dominantBaseline="middle"`, push pip group to `translate(..., cy + 15)` so the number sits centered and pips are unambiguously "below":
```tsx
<text x={cx} y={cy} textAnchor="middle" dominantBaseline="middle" ...>{number}</text>
{showPips && <g transform={`translate(${cx - (pips-1)*3.75}, ${cy + 15})`}>...</g>}
```

### P2-4 · Log still below the fold at 1366×720
**File:** `panel.jsx:210–216` (unchanged from v1)

Flagged in v1 P2-8, still not moved. At 720p the panel order is brand → turn card → phase title → dice → players (4 rows) → your hand → dev (conditional) → actions → bank trade → log. The log scrolls off-screen during setup. Classroom context: kids need to see *what just happened* to learn the rules.

**Fix options:**
- Reorder: put log immediately under the turn card.
- Make log a fixed footer band, not scroll-dependent.
- Collapse `Actions` and `Bank trade` into an expando during setup (they're disabled anyway).

### P2-5 · Primary button is orange ≈ P1 (You) color
**File:** `styles.css:346`

Still there: `.btn.primary` uses `color-mix(in oklch, var(--p1) 92%, white 8%)` → gradient to `var(--p1) 75%` + black. Button literally *is* the current player's color token. Visually elegant when P1 is playing, semantically confused when P4 (teal) is. The "End turn" CTA looks like the active-player identity.

**Fix:** decouple. Either neutralize primary to parchment-brown gradient, or dynamically theme primary with the current player's color (`var(--btn-primary)` set from React). I'd lean decouple — the "End turn" action is a game verb, not a player identity.

### P2-6 · `--p2` (Albrecht, `#c73a2e`) ≈ red chit ink (`#b91c1c`) ≈ brick mid (`#b34a2a`)
**File:** `styles.css:44, 48`, `board.jsx:272`

When Albrecht places a settlement on a brick hex next to a 6 or 8 chit, you get: red piece on red-orange hex with red-outlined red-number chit nearby. The four semantically distinct reds collapse into one. Not fixable via tokens alone (Catan's red player is canonical); mitigate by darkening Albrecht to `#a02020` and pushing brick-mid toward more orange (`#c06030`).

**Tradeoff:** deviates from the classic Catan palette further than P4 → teal already does. Tolerable if you commit to "Katan has a distinct board identity" — which the Cormorant + IBM Plex Mono type system already signals.

### P2-7 · `.stat-pill.vp` no longer visually distinct after v1 P2-2 fix
**File:** `styles.css:266–269`

The v1 fix made `.stat-pill.vp` use the same background/border as the other pills, delegating distinction to `.pill-n { color: player-color }`. The intent was consistent visual weight. Result: all three pills look identical at a glance. For a game where you're comparing opponents' progress, VP should be the most prominent pill in the row.

**Fix:** bring back weight on VP but with color-mix, not a different treatment:
```css
.stat-pill.vp { background: color-mix(in oklch, var(--parch-50) 60%, transparent); border-color: var(--parch-rule); }
.stat-pill.vp .pill-n { font-size: 13px; } /* vs default 11px */
```

### P2-8 · `pointerEvents: 'none'` on `.hex-tile` disables hex-click for robber placement
**File:** `board.jsx:235`

Robber-placement phase renders a separate `.robber-spot` overlay, so clicking on a hex reaches that overlay and works. But the side effect is: you can't add hex-hover states (e.g., "this hex will produce X when you roll 8") without reworking the pointer-event routing. Not a bug today, a constraint to watch.

### P2-9 · Tweaks `EDITMODE-BEGIN`/`EDITMODE-END` block
**File:** `game.jsx:68–73`

Leaving this here isn't wrong but it's a fingerprint of whatever prototyping tool was used. If this ships to students, the edit-mode postMessage listener at `:77–86` is still live and could be poked from an iframe parent. Low risk in a school-only deployment but worth gating behind `process.env.NODE_ENV === 'development'`.

### P2-10 · `.rcard.wheat` text color branches on the card but `.rl` label opacity is 0.95
**File:** `styles.css:287, 304`

Wheat card uses `color:#3c2a07` (dark on yellow), all other cards use `color: white`. But `.rl` has `opacity: .95` baseline which, stacked with the dark text on wheat, is fine — and stacked with white text on the others, also fine. When `.zero` kicks in (`opacity: .45`), the effective label opacity is `.45 * .95` on already-desaturated color. Legibility dies. Mitigated entirely if P1-3 (phase-aware zero) lands.

### P2-11 · `useLS` writes localStorage on every render that touches state
**File:** `game.jsx:22–29`

```ts
useEffect(()=>{ try { localStorage.setItem(key, JSON.stringify(v)); } catch(e){} }, [key,v]);
```

Every state update writes LS synchronously. On a 60Hz roll animation or rapid action sequence this is fine, but during AI turn resolution with `aiSpeed: 900` it writes 8–12 keys per turn. Classroom Chromebooks with aggressive power-saving can stall on LS writes.

**Fix:** debounce. Fold all game state into one reducer + one persisted key; write through a 200ms debounced effect.

### P2-12 · `computeHarbors` falls back to "first coastal side" on mismatch
**File:** `board.jsx:143–147`

If the hard-coded `PERIM[i].side` isn't coastal on the current layout, it falls back to whichever side has no neighbor. That's a safety net, but it means the fallback can pick an *adjacent* coastal edge that a different harbor might also want — two harbors on the same coastal segment — if multiple `PERIM` entries fall back together.

**Fix:** track assigned `(tileIdx, side)` pairs and skip collisions:
```ts
const assigned = new Set<string>();
return PERIM.map((p, i) => {
  const t = tiles[p.idx];
  let side = p.side;
  if (!isCoastal(t, side) || assigned.has(`${p.idx}:${side}`)) {
    for (let s = 0 as Side; s < 6; s++ as Side) {
      if (isCoastal(t, s) && !assigned.has(`${p.idx}:${s}`)) { side = s; break; }
    }
  }
  assigned.add(`${p.idx}:${side}`);
  return { tileIdx: p.idx, side, kind: HARBOR_KINDS[i] };
});
```
Or, more robust: drop the hand-maintained `PERIM` + fallback and derive the 9 harbor positions deterministically by walking coastal edges clockwise from the top-most coastal edge, skipping every second one (the canonical Catan harbor cadence).

### P2-13 · Ocean inner path is drawn twice (gradient + waves) — fine, but cost
**File:** `board.jsx:508–509`

Two full `<path d={dInner}>` paints — one for the radial gradient, one for the wave pattern. Could be combined by painting waves inside the gradient definition, saving one path. Micro-optimization; flag only if paint performance ever matters.

### P2-14 · `isSetup` phase check duplicated between `panel.jsx:67` and `board.jsx`
**File:** `panel.jsx:67`

```ts
const isSetup = phase.startsWith('placeSettlement') || phase.startsWith('placeRoad');
```

Define this once in a shared selector:
```ts
export const isSetupPhase = (p: Phase): boolean =>
  p === 'placeSettlement1' || p === 'placeSettlement2' ||
  p === 'placeRoad1' || p === 'placeRoad2';
```
`startsWith` on a phase enum is a code smell — exhaustive switch in TS makes new phases a compile error instead of a silent miss.

### P2-15 · `Board` still takes 8 flat props
**File:** `board.jsx:424`

V1 flagged 7 props, now `showPips` added = 8. Still workable, but see v1 P2-10. Next addition should trigger the compound-components refactor.

---

## Strategic / Catan-rules notes

A few correctness points against the rulebook that aren't UI bugs but are worth locking down:

- **Placement order / snake:** `game.jsx:48–49` tracks `setupStep` and `setupDir` (snake reverse for placement 2). Good. Verify that `placeSettlement2` placement grants resources from *all three adjacent hexes including desert* (code at `:161–172` looks correct — skips desert, yields 0/1/2/3 resources). Note: in the official base rulebook, a settlement adjacent to zero-resource tiles simply collects nothing — your current "founded a settlement in the desert" log message at `:175` is friendly phrasing for a placement on a coastal vertex touching only ocean/desert.

- **Longest Road flip:** not visible in this screenshot — flag for later. Once `buildRoad` lands, the recompute needs to handle the "opponent's settlement breaks your road" rule. The current `legalRoadEdges` at `:393–411` correctly checks that an opponent's settlement blocks road continuity (line 405 `settlements[v]?.playerId && settlements[v].playerId !== playerId`). Extend the same guard to the Longest Road length calculation when you add it.

- **Robber steal UI:** `moveRobber` phase is handled, but I don't see a victim-selection modal. When the robber lands on a hex with multiple adjacent opposing settlements, the rules require the mover to choose one to steal from. Make sure the TS port gets a Radix dialog for this — `role="button"` on the hex isn't sufficient.

- **7-to-10 surprise-win window:** no UI affordance yet for "here are the dev cards you could play this turn." Once Largest Army and Year of Plenty / Road Building are wired, the `rolled` phase should surface a "play dev card" button separately from the build buttons so the reveal moment is discrete.

---

## Suggested fix order

1. **P0-1 robber init validation** — visible regression, 5-minute fix. Ship tonight.
2. **P0-2 LS namespace by layout version** — same class of bug, prevents future mysteries.
3. **P0-3 sync `ts/` port** — one mechanical commit. After this the TS tree is actually a valid build target.
4. **P1-3 phase-aware hand** — big visual payoff for a small CSS change.
5. **P1-1 roving tabindex + arrow keys** — closes the a11y spec gap you explicitly called out.
6. **P1-2 `role="img"`/`aria-labelledby`** — same PR as P1-1.
7. **P1-4 VP progress typography promotion.**
8. **P2-1 `React.memo` on tile primitives** — 10 min, meaningful paint improvement.
9. Everything else as paint-over.

Estimated: ~2 focused hours for P0s + P1s. The TS sync is the single biggest unit of work and the highest-value chunk — it turns the project from "JSX prototype with TS aspirations" into "TS project with matching JSX reference."

---

## Net grade vs v1

**v1 → v2 delta:** major. Board now *looks* and *plays* like Catan. The regressions v2 finds are mostly either (a) the foreseeable second-order effects of introducing persistence (LS keys outlive the data they describe) or (b) the TS port quietly rotting while the JSX got fixed. Neither is a "we built the wrong thing" class of problem — both are "we shipped the right thing and need to shore up the backbone around it." Which is the right kind of audit to be writing after a fix pass.
